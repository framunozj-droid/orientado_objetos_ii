package model;

import java.util.Random;

public class Repartidor implements Runnable {

    private String nombre;
    private ZonaDeCarga zonaDeCarga;

    public Repartidor(String nombre, ZonaDeCarga zonaDeCarga) {
        this.nombre = nombre;
        this.zonaDeCarga = zonaDeCarga;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void run() {

        Random aleatorio = new Random();

        while (true) {

            Pedido pedido = zonaDeCarga.retirarPedido();

            if (pedido == null) {
                break;
            }

            try {

                System.out.println();

                System.out.println(
                        "[Repartidor - " + nombre + "] Retirando pedido #"
                                + pedido.getId() + "..."
                );

                pedido.setEstado(EstadoPedido.EN_REPARTO);

                System.out.println(
                        "[Repartidor - " + nombre + "] Estado: "
                                + pedido.getEstado()
                );

                System.out.println(
                        "[Repartidor - " + nombre + "] Entregando pedido #"
                                + pedido.getId() + "..."
                );

                int tiempoEspera = aleatorio.nextInt(2000) + 1000;

                Thread.sleep(tiempoEspera);

                pedido.setEstado(EstadoPedido.ENTREGADO);

                System.out.println(
                        "[Repartidor - " + nombre + "] Estado: "
                                + pedido.getEstado()
                );

            } catch (InterruptedException error) {

                System.out.println(
                        "El repartidor " + nombre
                                + " fue interrumpido."
                );

                Thread.currentThread().interrupt();
            }
        }

        System.out.println(
                "[Repartidor - " + nombre
                        + "] No quedan pedidos."
        );
    }
}