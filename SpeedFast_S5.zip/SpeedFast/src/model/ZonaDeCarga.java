package model;

import java.util.ArrayList;

public class ZonaDeCarga {

    private ArrayList<Pedido> listaPedidos;

    public ZonaDeCarga() {
        listaPedidos = new ArrayList<Pedido>();

        System.out.println("[Zona de carga inicializada]");
        System.out.println();
    }

    public synchronized void agregarPedido(Pedido pedido) {

        listaPedidos.add(pedido);

        System.out.println(
                "Pedido #" + pedido.getId()
                + " agregado. Destino: "
                + pedido.getDireccionEntrega()
        );
    }

    public synchronized Pedido retirarPedido() {

        if (listaPedidos.size() > 0) {

            Pedido pedido = listaPedidos.get(0);

            listaPedidos.remove(0);

            return pedido;
        }

        return null;
    }

    public synchronized boolean hayPedidos() {

        return listaPedidos.size() > 0;
    }
}