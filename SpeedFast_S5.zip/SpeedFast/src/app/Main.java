package app;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import model.Pedido;
import model.Repartidor;
import model.ZonaDeCarga;

public class Main {

    public static void main(String[] args) {

        ZonaDeCarga zonaDeCarga = new ZonaDeCarga();

        Pedido pedido1 = new Pedido(
                1,
                "Santiago Centro"
        );

        Pedido pedido2 = new Pedido(
                2,
                "Providencia"
        );

        Pedido pedido3 = new Pedido(
                3,
                "Ñuñoa"
        );

        Pedido pedido4 = new Pedido(
                4,
                "Recoleta"
        );

        Pedido pedido5 = new Pedido(
                5,
                "Las Condes"
        );

        Pedido pedido6 = new Pedido(
                6,
                "Maipú"
        );

        zonaDeCarga.agregarPedido(pedido1);
        zonaDeCarga.agregarPedido(pedido2);
        zonaDeCarga.agregarPedido(pedido3);
        zonaDeCarga.agregarPedido(pedido4);
        zonaDeCarga.agregarPedido(pedido5);
        zonaDeCarga.agregarPedido(pedido6);

        System.out.println();

        Repartidor juan = new Repartidor(
                "Juan",
                zonaDeCarga
        );

        Repartidor camila = new Repartidor(
                "Camila",
                zonaDeCarga
        );

        Repartidor pedro = new Repartidor(
                "Pedro",
                zonaDeCarga
        );

        ExecutorService ejecutor =
                Executors.newFixedThreadPool(3);

        ejecutor.execute(juan);
        ejecutor.execute(camila);
        ejecutor.execute(pedro);

        ejecutor.shutdown();

        try {

            ejecutor.awaitTermination(
                    1,
                    TimeUnit.MINUTES
            );

        } catch (InterruptedException error) {

            System.out.println(
                    "La ejecución principal fue interrumpida."
            );

            Thread.currentThread().interrupt();
        }

        System.out.println();
        System.out.println(
                "Todos los pedidos han sido entregados correctamente"
        );
    }
}