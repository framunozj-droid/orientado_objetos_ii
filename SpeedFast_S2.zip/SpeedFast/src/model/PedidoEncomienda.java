package model;

public class PedidoEncomienda extends Pedido {

    public PedidoEncomienda() {
        super();
    }

    public PedidoEncomienda(int idPedido, String direccionEntrega, double distanciaKm) {
        super(idPedido, direccionEntrega, distanciaKm);
    }

    @Override
    public int calcularTiempoEntrega() {

        double calculo = 20 + (getDistanciaKm() * 1.5);

        int tiempo = (int) calculo;

        return tiempo;
    }

    @Override
    public void mostrarResumen() {
        System.out.println("PedidoEncomienda #" + getIdPedido());
        System.out.println("Dirección: " + getDireccionEntrega());
        System.out.println("Distancia: " + getDistanciaKm() + " km");
    }
}