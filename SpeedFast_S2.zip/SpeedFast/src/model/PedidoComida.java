package model;

public class PedidoComida extends Pedido {

    public PedidoComida() {
        super();
    }

    public PedidoComida(int idPedido, String direccionEntrega, double distanciaKm) {
        super(idPedido, direccionEntrega, distanciaKm);
    }

    @Override
    public int calcularTiempoEntrega() {

        int tiempo = 15 + (int) (getDistanciaKm() * 2);

        return tiempo;
    }

    @Override
    public void mostrarResumen() {
        System.out.println("PedidoComida #" + getIdPedido());
        System.out.println("Dirección: " + getDireccionEntrega());
        System.out.println("Distancia: " + getDistanciaKm() + " km");
    }
}