package app;

import javax.swing.SwingUtilities;
import vista.VentanaLogin;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(VentanaLogin::new);
    }
}
