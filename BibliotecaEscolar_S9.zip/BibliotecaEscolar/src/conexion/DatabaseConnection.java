
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static DatabaseConnection instancia;

    private final String url =
            "jdbc:mysql://localhost:3306/biblioteca";

    private final String usuario = "root";
    private final String clave = "admin";

    private DatabaseConnection() {
    }

    public static synchronized DatabaseConnection getInstance() {

        if (instancia == null) {
            instancia = new DatabaseConnection();
        }

        return instancia;
    }

    public Connection getConnection() throws SQLException {

        return DriverManager.getConnection(
                url,
                usuario,
                clave
        );
    }
}
