package dao;

import conexion.DatabaseConnection;
import modelo.Estudiante;
import java.sql.*;
import java.util.*;

public class EstudianteDAO {
    private Estudiante convertir(ResultSet r) throws SQLException {
        return new Estudiante(r.getInt("id"), r.getString("nombre"), r.getString("rut"), r.getString("curso"),
                r.getString("correo"));
    }

    public List<Estudiante> listarTodos() throws SQLException {
        List<Estudiante> l = new ArrayList<>();
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("SELECT * FROM estudiantes ORDER BY id");
                ResultSet r = p.executeQuery()) {
            while (r.next())
                l.add(convertir(r));
        }
        return l;
    }

    public Estudiante buscarPorRut(String rut) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("SELECT * FROM estudiantes WHERE rut=?")) {
            p.setString(1, rut);
            try (ResultSet r = p.executeQuery()) {
                return r.next() ? convertir(r) : null;
            }
        }
    }

    public Estudiante buscarPorId(int id) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("SELECT * FROM estudiantes WHERE id=?")) {
            p.setInt(1, id);
            try (ResultSet r = p.executeQuery()) {
                return r.next() ? convertir(r) : null;
            }
        }
    }

    public boolean guardar(Estudiante e) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c
                        .prepareStatement("INSERT INTO estudiantes(nombre,rut,curso,correo) VALUES(?,?,?,?)")) {
            p.setString(1, e.getNombre());
            p.setString(2, e.getRut());
            p.setString(3, e.getCurso());
            p.setString(4, e.getCorreo());
            return p.executeUpdate() > 0;
        }
    }

    public boolean actualizar(Estudiante e) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c
                        .prepareStatement("UPDATE estudiantes SET nombre=?,rut=?,curso=?,correo=? WHERE id=?")) {
            p.setString(1, e.getNombre());
            p.setString(2, e.getRut());
            p.setString(3, e.getCurso());
            p.setString(4, e.getCorreo());
            p.setInt(5, e.getId());
            return p.executeUpdate() > 0;
        }
    }

    public boolean eliminar(int id) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("DELETE FROM estudiantes WHERE id=?")) {
            p.setInt(1, id);
            return p.executeUpdate() > 0;
        }
    }
}
