package dao;

import conexion.DatabaseConnection;
import modelo.Categoria;
import java.sql.*;
import java.util.*;

public class CategoriaDAO {
    public List<Categoria> listarTodos() throws SQLException {
        List<Categoria> l = new ArrayList<>();
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("SELECT * FROM categorias ORDER BY id");
                ResultSet r = p.executeQuery()) {
            while (r.next())
                l.add(new Categoria(r.getInt("id"), r.getString("nombre")));
        }
        return l;
    }

    public boolean guardar(Categoria x) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("INSERT INTO categorias(nombre) VALUES(?)")) {
            p.setString(1, x.getNombre());
            return p.executeUpdate() > 0;
        }
    }

    public boolean actualizar(Categoria x) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("UPDATE categorias SET nombre=? WHERE id=?")) {
            p.setString(1, x.getNombre());
            p.setInt(2, x.getId());
            return p.executeUpdate() > 0;
        }
    }

    public boolean eliminar(int id) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("DELETE FROM categorias WHERE id=?")) {
            p.setInt(1, id);
            return p.executeUpdate() > 0;
        }
    }
}
