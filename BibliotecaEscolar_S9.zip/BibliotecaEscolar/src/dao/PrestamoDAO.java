package dao;

import conexion.DatabaseConnection;
import modelo.Prestamo;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;

public class PrestamoDAO {
    public synchronized boolean registrarPrestamo(int estudiante, int libro) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection()) {
            c.setAutoCommit(false);
            try {
                try (PreparedStatement p = c
                        .prepareStatement("UPDATE libros SET stock=stock-1 WHERE id=? AND stock>0")) {
                    p.setInt(1, libro);
                    if (p.executeUpdate() != 1) {
                        c.rollback();
                        return false;
                    }
                }
                try (PreparedStatement p = c.prepareStatement(
                        "INSERT INTO prestamos(id_estudiante,id_libro,fecha_prestamo,fecha_devolucion,devuelto) VALUES(?,?,?,?,FALSE)")) {
                    p.setInt(1, estudiante);
                    p.setInt(2, libro);
                    p.setDate(3, java.sql.Date.valueOf(LocalDate.now()));
                    p.setDate(4, java.sql.Date.valueOf(LocalDate.now().plusDays(7)));
                    p.executeUpdate();
                }
                c.commit();
                return true;
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    public synchronized boolean devolverLibro(int idPrestamo, int estudianteAutorizado) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection()) {
            c.setAutoCommit(false);
            try {
                int libro;
                try (PreparedStatement p = c.prepareStatement(
                        "SELECT id_libro,id_estudiante,devuelto FROM prestamos WHERE id=? FOR UPDATE")) {
                    p.setInt(1, idPrestamo);
                    try (ResultSet r = p.executeQuery()) {
                        if (!r.next() || r.getBoolean("devuelto")
                                || (estudianteAutorizado > 0 && r.getInt("id_estudiante") != estudianteAutorizado)) {
                            c.rollback();
                            return false;
                        }
                        libro = r.getInt("id_libro");
                    }
                }
                try (PreparedStatement p = c
                        .prepareStatement("UPDATE prestamos SET devuelto=TRUE WHERE id=? AND devuelto=FALSE")) {
                    p.setInt(1, idPrestamo);
                    if (p.executeUpdate() != 1) {
                        c.rollback();
                        return false;
                    }
                }
                try (PreparedStatement p = c.prepareStatement("UPDATE libros SET stock=stock+1 WHERE id=?")) {
                    p.setInt(1, libro);
                    if (p.executeUpdate() != 1)
                        throw new SQLException("No se pudo reponer el stock");
                }
                c.commit();
                return true;
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    public List<Prestamo> listarTodos() throws SQLException {
        return listarPorEstudiante(0);
    }

    public List<Prestamo> listarPorEstudiante(int id) throws SQLException {
        List<Prestamo> lista = new ArrayList<>();
        String sql = "SELECT * FROM prestamos" + (id > 0 ? " WHERE id_estudiante=?" : "") + " ORDER BY id DESC";
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement(sql)) {
            if (id > 0)
                p.setInt(1, id);
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) {
                    java.sql.Date inicio = r.getDate("fecha_prestamo"), fin = r.getDate("fecha_devolucion");
                    lista.add(new Prestamo(r.getInt("id"), r.getInt("id_estudiante"), r.getInt("id_libro"),
                            inicio == null ? null : inicio.toLocalDate(), fin == null ? null : fin.toLocalDate(),
                            r.getBoolean("devuelto")));
                }
            }
        }
        return lista;
    }

    public List<Prestamo> listarActivos() throws SQLException {
        List<Prestamo> l = new ArrayList<>();
        for (Prestamo p : listarTodos())
            if (!p.isDevuelto())
                l.add(p);
        return l;
    }
}
