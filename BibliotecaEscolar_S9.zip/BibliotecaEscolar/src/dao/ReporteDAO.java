package dao;

import conexion.DatabaseConnection;
import java.sql.*;
import java.util.*;

public class ReporteDAO {
    private List<Object[]> consultar(String sql, int estudiante) throws SQLException {
        List<Object[]> lista = new ArrayList<>();
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement(sql)) {
            if (estudiante > 0)
                p.setInt(1, estudiante);
            try (ResultSet r = p.executeQuery()) {
                int n = r.getMetaData().getColumnCount();
                while (r.next()) {
                    Object[] fila = new Object[n];
                    for (int i = 0; i < n; i++)
                        fila[i] = r.getObject(i + 1);
                    lista.add(fila);
                }
            }
        }
        return lista;
    }

    public List<Object[]> librosMasPrestados() throws SQLException {
        return consultar(
                "SELECT l.titulo,l.autor,COUNT(p.id) total FROM libros l LEFT JOIN prestamos p ON p.id_libro=l.id GROUP BY l.id,l.titulo,l.autor ORDER BY total DESC,l.titulo",
                0);
    }

    public List<Object[]> historialPorEstudiante(int id) throws SQLException {
        return consultar(
                "SELECT l.titulo,p.fecha_prestamo,p.fecha_devolucion,CASE WHEN p.devuelto THEN 'Devuelto' ELSE 'Pendiente' END estado FROM prestamos p JOIN libros l ON l.id=p.id_libro WHERE p.id_estudiante=? ORDER BY p.fecha_prestamo DESC",
                id);
    }

    public List<Object[]> prestamosActivos() throws SQLException {
        return consultar(
                "SELECT e.nombre,l.titulo,p.fecha_prestamo,p.fecha_devolucion FROM prestamos p JOIN estudiantes e ON e.id=p.id_estudiante JOIN libros l ON l.id=p.id_libro WHERE p.devuelto=FALSE ORDER BY p.fecha_devolucion",
                0);
    }
}
