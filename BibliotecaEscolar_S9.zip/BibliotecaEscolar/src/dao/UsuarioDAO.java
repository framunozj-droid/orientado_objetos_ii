package dao;

import conexion.DatabaseConnection;
import modelo.Usuario;
import java.sql.*;
import java.util.*;

public class UsuarioDAO {
    private Usuario convertir(ResultSet r) throws SQLException {
        return new Usuario(r.getInt("id"), r.getString("nombre"), r.getString("rut"), r.getString("correo"),
                r.getString("contraseña"), r.getString("rol"));
    }

    public Usuario iniciarSesion(String correo, String clave) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("SELECT * FROM usuarios WHERE correo=? AND contraseña=?")) {
            p.setString(1, correo);
            p.setString(2, clave);
            try (ResultSet r = p.executeQuery()) {
                return r.next() ? convertir(r) : null;
            }
        }
    }

    public List<Usuario> listarTodos() throws SQLException {
        List<Usuario> l = new ArrayList<>();
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("SELECT * FROM usuarios ORDER BY id");
                ResultSet r = p.executeQuery()) {
            while (r.next())
                l.add(convertir(r));
        }
        return l;
    }

    public boolean guardar(Usuario u) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c
                        .prepareStatement("INSERT INTO usuarios(nombre,rut,correo,contraseña,rol) VALUES(?,?,?,?,?)")) {
            p.setString(1, u.getNombre());
            p.setString(2, u.getRut());
            p.setString(3, u.getCorreo());
            p.setString(4, u.getContrasena());
            p.setString(5, u.getRol());
            return p.executeUpdate() > 0;
        }
    }

    public boolean actualizar(Usuario u) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement(
                        "UPDATE usuarios SET nombre=?,rut=?,correo=?,contraseña=?,rol=? WHERE id=?")) {
            p.setString(1, u.getNombre());
            p.setString(2, u.getRut());
            p.setString(3, u.getCorreo());
            p.setString(4, u.getContrasena());
            p.setString(5, u.getRol());
            p.setInt(6, u.getId());
            return p.executeUpdate() > 0;
        }
    }

    public boolean eliminar(int id) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("DELETE FROM usuarios WHERE id=?")) {
            p.setInt(1, id);
            return p.executeUpdate() > 0;
        }
    }
}
