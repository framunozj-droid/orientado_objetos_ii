package dao;

import conexion.DatabaseConnection;
import modelo.Libro;
import java.sql.*;
import java.util.*;

public class LibroDAO {
    private Libro convertir(ResultSet r) throws SQLException {
        return new Libro(r.getInt("id"), r.getString("titulo"), r.getString("autor"), r.getString("isbn"),
                r.getString("editorial"), r.getInt("stock"), r.getInt("id_categoria"));
    }

    public List<Libro> listarTodos() throws SQLException {
        List<Libro> l = new ArrayList<>();
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("SELECT * FROM libros ORDER BY id");
                ResultSet r = p.executeQuery()) {
            while (r.next())
                l.add(convertir(r));
        }
        return l;
    }

    public Libro buscarPorId(int id) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("SELECT * FROM libros WHERE id=?")) {
            p.setInt(1, id);
            try (ResultSet r = p.executeQuery()) {
                return r.next() ? convertir(r) : null;
            }
        }
    }

    public boolean guardar(Libro l) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement(
                        "INSERT INTO libros(titulo,autor,isbn,editorial,stock,id_categoria) VALUES(?,?,?,?,?,?)")) {
            poner(p, l);
            return p.executeUpdate() > 0;
        }
    }

    public boolean actualizar(Libro l) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement(
                        "UPDATE libros SET titulo=?,autor=?,isbn=?,editorial=?,stock=?,id_categoria=? WHERE id=?")) {
            poner(p, l);
            p.setInt(7, l.getId());
            return p.executeUpdate() > 0;
        }
    }

    private void poner(PreparedStatement p, Libro l) throws SQLException {
        p.setString(1, l.getTitulo());
        p.setString(2, l.getAutor());
        p.setString(3, l.getIsbn());
        p.setString(4, l.getEditorial());
        p.setInt(5, l.getStock());
        p.setInt(6, l.getIdCategoria());
    }

    public boolean eliminar(int id) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().getConnection();
                PreparedStatement p = c.prepareStatement("DELETE FROM libros WHERE id=?")) {
            p.setInt(1, id);
            return p.executeUpdate() > 0;
        }
    }
}
