package modelo;

public class Estudiante extends Persona implements Mostrable {
    private String curso, correo;

    public Estudiante(int id, String nombre, String rut, String curso, String correo) {
        super(id, nombre, rut);
        this.curso = curso;
        this.correo = correo;
    }

    public String getCurso() {
        return curso;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCurso(String x) {
        curso = x;
    }

    public void setCorreo(String x) {
        correo = x;
    }

    public String obtenerDescripcion() {
        return nombre + " - " + curso;
    }

    public String mostrarInformacion() {
        return obtenerDescripcion();
    }

    public String toString() {
        return nombre + " - " + rut;
    }
}
