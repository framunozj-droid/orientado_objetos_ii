package modelo;

public class Libro implements Mostrable {
    private final int id;
    private String titulo, autor, isbn, editorial;
    private int stock, idCategoria;

    public Libro(int id, String titulo, String autor, String isbn, String editorial, int stock, int idCategoria) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.editorial = editorial;
        this.stock = stock;
        this.idCategoria = idCategoria;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getEditorial() {
        return editorial;
    }

    public int getStock() {
        return stock;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setTitulo(String x) {
        titulo = x;
    }

    public void setAutor(String x) {
        autor = x;
    }

    public void setIsbn(String x) {
        isbn = x;
    }

    public void setEditorial(String x) {
        editorial = x;
    }

    public void setStock(int x) {
        stock = x;
    }

    public void setIdCategoria(int x) {
        idCategoria = x;
    }

    public String mostrarInformacion() {
        return titulo + " - " + autor;
    }

    public String toString() {
        return titulo + " (stock: " + stock + ")";
    }
}
