package modelo;

public class Usuario extends Persona implements Mostrable {
    private String correo, contrasena, rol;

    public Usuario(int id, String nombre, String rut, String correo, String contrasena, String rol) {
        super(id, nombre, rut);
        this.correo = correo;
        this.contrasena = contrasena;
        this.rol = rol;
    }

    public String getCorreo() {
        return correo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public String getRol() {
        return rol;
    }

    public void setCorreo(String x) {
        correo = x;
    }

    public void setContrasena(String x) {
        contrasena = x;
    }

    public void setRol(String x) {
        rol = x;
    }

    public String obtenerDescripcion() {
        return nombre + " - " + rol;
    }

    public String mostrarInformacion() {
        return obtenerDescripcion();
    }
}
