package modelo;

public interface Mostrable {
    String mostrarInformacion();
}
