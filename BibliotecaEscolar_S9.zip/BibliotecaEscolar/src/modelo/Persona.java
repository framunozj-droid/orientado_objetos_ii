package modelo;

public abstract class Persona {
    protected int id;
    protected String nombre, rut;

    public Persona(int id, String nombre, String rut) {
        this.id = id;
        this.nombre = nombre;
        this.rut = rut;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRut() {
        return rut;
    }

    public void setNombre(String x) {
        nombre = x;
    }

    public void setRut(String x) {
        rut = x;
    }

    public abstract String obtenerDescripcion();
}
