package vista;

import dao.CategoriaDAO;
import modelo.Categoria;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class VentanaCategorias extends JFrame {
    private final CategoriaDAO dao = new CategoriaDAO();
    private final JTextField campoNombre = new JTextField(25);
    private final DefaultTableModel modelo = new DefaultTableModel(new String[]{"ID", "Nombre"}, 0) {
        @Override public boolean isCellEditable(int fila, int columna) { return false; }
    };
    private final JTable tabla = new JTable(modelo);
    private int idSeleccionado = 0;

    public VentanaCategorias() {
        setTitle("Biblioteca Escolar - Categorías");
        setSize(620, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JPanel arriba = new JPanel(new BorderLayout(8, 8));
        JPanel formulario = new JPanel(new BorderLayout(8, 8));
        formulario.add(new JLabel("Nombre:"), BorderLayout.WEST);
        formulario.add(campoNombre, BorderLayout.CENTER);
        arriba.add(formulario, BorderLayout.NORTH);
        JPanel botones = new JPanel();
        JButton guardar = new JButton("Guardar");
        JButton actualizar = new JButton("Actualizar");
        JButton eliminar = new JButton("Eliminar");
        JButton limpiar = new JButton("Limpiar");
        JButton recargar = new JButton("Recargar");
        for (JButton boton : new JButton[]{guardar, actualizar, eliminar, limpiar, recargar}) botones.add(boton);
        arriba.add(botones, BorderLayout.SOUTH);
        arriba.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        add(arriba, BorderLayout.NORTH);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setAutoCreateRowSorter(true);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                int fila = tabla.convertRowIndexToModel(tabla.getSelectedRow());
                idSeleccionado = (int) modelo.getValueAt(fila, 0);
                campoNombre.setText((String) modelo.getValueAt(fila, 1));
            }
        });
        guardar.addActionListener(e -> ejecutar("guardar"));
        actualizar.addActionListener(e -> ejecutar("actualizar"));
        eliminar.addActionListener(e -> ejecutar("eliminar"));
        limpiar.addActionListener(e -> limpiar());
        recargar.addActionListener(e -> cargar());
        cargar();
        setVisible(true);
    }

    private void ejecutar(String accion) {
        String nombre = campoNombre.getText().trim();
        if (!accion.equals("eliminar") && nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese el nombre de la categoría.");
            return;
        }
        if (!accion.equals("guardar") && idSeleccionado == 0) {
            JOptionPane.showMessageDialog(this, "Seleccione una categoría.");
            return;
        }
        if (accion.equals("eliminar") && JOptionPane.showConfirmDialog(this,
                "¿Eliminar la categoría seleccionada?", "Confirmar", JOptionPane.YES_NO_OPTION)
                != JOptionPane.YES_OPTION) return;
        try {
            boolean correcto;
            switch (accion) {
                case "guardar": correcto = dao.guardar(new Categoria(0, nombre)); break;
                case "actualizar": correcto = dao.actualizar(new Categoria(idSeleccionado, nombre)); break;
                default: correcto = dao.eliminar(idSeleccionado);
            }
            if (correcto) {
                limpiar();
                cargar();
                JOptionPane.showMessageDialog(this, "Operación realizada correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "No se realizaron cambios.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo completar la operación. "
                    + "Compruebe si la categoría tiene libros asociados.\n" + ex.getMessage());
        }
    }

    private void limpiar() {
        idSeleccionado = 0;
        campoNombre.setText("");
        tabla.clearSelection();
    }

    private void cargar() {
        try {
            modelo.setRowCount(0);
            for (Categoria categoria : dao.listarTodos()) {
                modelo.addRow(new Object[]{categoria.getId(), categoria.getNombre()});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar categorías: " + ex.getMessage());
        }
    }
}
