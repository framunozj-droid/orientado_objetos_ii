package vista;

import dao.EstudianteDAO;
import modelo.Estudiante;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class VentanaEstudiantes extends JFrame {
    private final EstudianteDAO dao = new EstudianteDAO();
    private final JTextField nombre = new JTextField(), rut = new JTextField(), curso = new JTextField(),
            correo = new JTextField();
    private final DefaultTableModel datos = new DefaultTableModel(
            new String[] { "ID", "Nombre", "RUT", "Curso", "Correo" }, 0) {
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    };
    private final JTable tabla = new JTable(datos);
    private int seleccionado = 0;

    public VentanaEstudiantes() {
        setTitle("Gestión de estudiantes");
        setSize(850, 540);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JPanel form = new JPanel(new GridLayout(4, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(20, 30, 15, 30));
        String[] etiquetas = { "Nombre", "RUT", "Curso", "Correo" };
        JTextField[] campos = { nombre, rut, curso, correo };
        for (int i = 0; i < 4; i++) {
            form.add(new JLabel(etiquetas[i]));
            form.add(campos[i]);
        }
        JPanel botones = new JPanel();
        for (String accion : new String[] { "Guardar", "Actualizar", "Eliminar", "Limpiar" }) {
            JButton b = new JButton(accion);
            botones.add(b);
            b.addActionListener(e -> {
                switch (accion) {
                    case "Guardar":
                        guardar(false);
                        break;
                    case "Actualizar":
                        guardar(true);
                        break;
                    case "Eliminar":
                        eliminar();
                        break;
                    default:
                        limpiar();
                }
            });
        }
        JPanel superior = new JPanel(new BorderLayout());
        superior.add(form);
        superior.add(botones, BorderLayout.SOUTH);
        add(superior, BorderLayout.NORTH);
        tabla.setAutoCreateRowSorter(true);
        add(new JScrollPane(tabla));
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting())
                seleccionar();
        });
        cargar();
        setVisible(true);
    }

    private void cargar() {
        try {
            datos.setRowCount(0);
            for (Estudiante e : dao.listarTodos())
                datos.addRow(new Object[] { e.getId(), e.getNombre(), e.getRut(), e.getCurso(), e.getCorreo() });
        } catch (Exception e) {
            error(e);
        }
    }

    private void guardar(boolean actualizar) {
        try {
            if (actualizar && seleccionado == 0)
                throw new IllegalArgumentException("Seleccione un estudiante.");
            for (JTextField t : new JTextField[] { nombre, rut, curso, correo })
                if (t.getText().trim().isEmpty())
                    throw new IllegalArgumentException("Complete todos los campos.");
            if (!correo.getText().contains("@"))
                throw new IllegalArgumentException("Correo inválido.");
            Estudiante e = new Estudiante(seleccionado, nombre.getText().trim(), rut.getText().trim(),
                    curso.getText().trim(), correo.getText().trim());
            boolean ok = actualizar ? dao.actualizar(e) : dao.guardar(e);
            if (ok) {
                cargar();
                limpiar();
            }
        } catch (Exception e) {
            error(e);
        }
    }

    private void eliminar() {
        if (seleccionado == 0)
            return;
        if (JOptionPane.showConfirmDialog(this, "¿Eliminar estudiante?", "Confirmar",
                JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION)
            return;
        try {
            dao.eliminar(seleccionado);
            cargar();
            limpiar();
        } catch (Exception e) {
            error(e);
        }
    }

    private void seleccionar() {
        int v = tabla.getSelectedRow();
        if (v < 0)
            return;
        int f = tabla.convertRowIndexToModel(v);
        seleccionado = (int) datos.getValueAt(f, 0);
        JTextField[] campos = { nombre, rut, curso, correo };
        for (int i = 0; i < 4; i++)
            campos[i].setText(String.valueOf(datos.getValueAt(f, i + 1)));
    }

    private void limpiar() {
        seleccionado = 0;
        for (JTextField t : new JTextField[] { nombre, rut, curso, correo })
            t.setText("");
        tabla.clearSelection();
    }

    private void error(Exception e) {
        JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
