package vista;

import modelo.Usuario;
import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {
    private final Usuario usuario;

    public VentanaPrincipal(Usuario usuario) {
        this.usuario = usuario;
        setTitle("Biblioteca Escolar");
        setSize(540, 470);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JLabel encabezado = new JLabel("Biblioteca Escolar - " + usuario.obtenerDescripcion(), SwingConstants.CENTER);
        add(encabezado, BorderLayout.NORTH);
        JPanel panel = new JPanel(new GridLayout(6, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(25, 70, 25, 70));
        JButton categorias = new JButton("Gestión de categorías"), libros = new JButton("Gestión de libros"), estudiantes = new JButton("Gestión de estudiantes"),
                prestamos = new JButton("Préstamos y devoluciones"), reportes = new JButton("Reportes"),
                salir = new JButton("Cerrar sesión");
        boolean admin = "bibliotecario".equalsIgnoreCase(usuario.getRol());
        categorias.setEnabled(admin);
        libros.setEnabled(admin);
        estudiantes.setEnabled(admin);
        categorias.addActionListener(e -> new VentanaCategorias());
        libros.addActionListener(e -> new VentanaLibros());
        estudiantes.addActionListener(e -> new VentanaEstudiantes());
        prestamos.addActionListener(e -> new VentanaPrestamos(usuario));
        reportes.addActionListener(e -> new VentanaReportes(usuario));
        salir.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(this, "¿Cerrar sesión?", "Confirmar",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                dispose();
                new VentanaLogin();
            }
        });
        for (JButton b : new JButton[] { categorias, libros, estudiantes, prestamos, reportes, salir })
            panel.add(b);
        add(panel);
        setVisible(true);
    }
}
