
package vista;

import controlador.PrestamoControlador;
import dao.EstudianteDAO;
import dao.LibroDAO;
import dao.PrestamoDAO;

import modelo.Estudiante;
import modelo.Libro;
import modelo.Prestamo;
import modelo.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class VentanaPrestamos extends JFrame {

    private final Usuario usuario;

    private final EstudianteDAO estudianteDAO;
    private final LibroDAO libroDAO;
    private final PrestamoDAO prestamoDAO;
    private final PrestamoControlador controlador;

    private JComboBox<Estudiante> comboEstudiante;
    private JComboBox<Libro> comboLibro;

    private JTable tablaPrestamos;
    private DefaultTableModel modeloTabla;

    private JButton botonPrestar;
    private JButton botonDevolver;
    private JButton botonActualizar;

    private int idEstudianteSesion = 0;
    private boolean operacionEnCurso = false;

    public VentanaPrestamos(Usuario usuario) {

        this.usuario = usuario;

        estudianteDAO = new EstudianteDAO();
        libroDAO = new LibroDAO();
        prestamoDAO = new PrestamoDAO();
        controlador = new PrestamoControlador();

        setTitle("Biblioteca Escolar - Préstamos y Devoluciones");
        setSize(950, 570);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        crearComponentes();
        cargarDatos();

        setVisible(true);
    }

    private boolean esBibliotecario() {
        return "bibliotecario".equalsIgnoreCase(usuario.getRol());
    }

    private void crearComponentes() {

        JLabel titulo = new JLabel(
                "PRÉSTAMOS Y DEVOLUCIONES",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 20));

        comboEstudiante = new JComboBox<>();
        comboLibro = new JComboBox<>();

        JPanel formulario = new JPanel(
                new GridLayout(2, 2, 10, 10)
        );

        formulario.setBorder(
                BorderFactory.createEmptyBorder(20, 30, 10, 30)
        );

        formulario.add(new JLabel("Estudiante:"));
        formulario.add(comboEstudiante);

        formulario.add(new JLabel("Libro:"));
        formulario.add(comboLibro);

        botonPrestar = new JButton("Registrar Préstamo");
        botonDevolver = new JButton("Registrar Devolución");
        botonActualizar = new JButton("Actualizar Lista");

        JPanel panelBotones = new JPanel();

        panelBotones.add(botonPrestar);
        panelBotones.add(botonDevolver);
        panelBotones.add(botonActualizar);

        modeloTabla = new DefaultTableModel(
                new String[]{
                        "ID",
                        "Estudiante",
                        "Libro",
                        "Fecha Préstamo",
                        "Vencimiento",
                        "Estado"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tablaPrestamos = new JTable(modeloTabla);

        tablaPrestamos.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        tablaPrestamos.setAutoCreateRowSorter(true);

        JPanel superior = new JPanel(new BorderLayout());

        superior.add(titulo, BorderLayout.NORTH);
        superior.add(formulario, BorderLayout.CENTER);
        superior.add(panelBotones, BorderLayout.SOUTH);

        setLayout(new BorderLayout());

        add(superior, BorderLayout.NORTH);
        add(new JScrollPane(tablaPrestamos), BorderLayout.CENTER);

        botonPrestar.addActionListener(
                e -> registrarPrestamo()
        );

        botonDevolver.addActionListener(
                e -> devolverLibro()
        );

        botonActualizar.addActionListener(
                e -> cargarDatos()
        );
    }

    private void actualizarBotones(boolean habilitar) {

        botonPrestar.setEnabled(habilitar);
        botonDevolver.setEnabled(habilitar);
        botonActualizar.setEnabled(habilitar);
    }

    private void cargarDatos() {

        if (operacionEnCurso) {
            return;
        }

        operacionEnCurso = true;
        actualizarBotones(false);

        SwingWorker<List<Object>, Void> trabajador =
                new SwingWorker<List<Object>, Void>() {

            @Override
            protected List<Object> doInBackground()
                    throws Exception {

                List<Object> datos = new ArrayList<>();

                datos.add(estudianteDAO.listarTodos());
                datos.add(libroDAO.listarTodos());
                datos.add(prestamoDAO.listarTodos());

                return datos;
            }

            @Override
            @SuppressWarnings("unchecked")
            protected void done() {

                try {

                    List<Object> datos = get();

                    List<Estudiante> estudiantes =
                            (List<Estudiante>) datos.get(0);

                    List<Libro> libros =
                            (List<Libro>) datos.get(1);

                    List<Prestamo> prestamos =
                            (List<Prestamo>) datos.get(2);

                    comboEstudiante.removeAllItems();
                    comboLibro.removeAllItems();

                    idEstudianteSesion = 0;

                    if (esBibliotecario()) {

                        comboEstudiante.setEnabled(true);

                        for (Estudiante estudiante : estudiantes) {
                            comboEstudiante.addItem(estudiante);
                        }

                    } else {

                        comboEstudiante.setEnabled(false);

                        for (Estudiante estudiante : estudiantes) {

                            if (estudiante.getRut().equals(
                                    usuario.getRut())) {

                                idEstudianteSesion = estudiante.getId();
                                comboEstudiante.addItem(estudiante);
                                break;
                            }
                        }
                    }

                    for (Libro libro : libros) {
                        comboLibro.addItem(libro);
                    }

                    modeloTabla.setRowCount(0);

                    for (Prestamo prestamo : prestamos) {

                        if (!esBibliotecario()
                                && prestamo.getIdEstudiante()
                                != idEstudianteSesion) {
                            continue;
                        }

                        String nombreEstudiante =
                                buscarEstudiante(
                                        estudiantes,
                                        prestamo.getIdEstudiante()
                                );

                        String nombreLibro =
                                buscarLibro(
                                        libros,
                                        prestamo.getIdLibro()
                                );

                        String estado;

                        if (prestamo.isDevuelto()) {
                            estado = "Devuelto";
                        } else if (prestamo.estaAtrasado()) {
                            estado = "Atrasado";
                        } else {
                            estado = "En préstamo";
                        }

                        modeloTabla.addRow(new Object[]{
                                prestamo.getId(),
                                nombreEstudiante,
                                nombreLibro,
                                prestamo.getFechaPrestamo(),
                                prestamo.getFechaDevolucion(),
                                estado
                        });
                    }

                } catch (InterruptedException e) {

                    Thread.currentThread().interrupt();

                    mostrarError("Actualización interrumpida.");

                } catch (ExecutionException e) {

                    mostrarError(
                            "Error al actualizar: "
                            + e.getCause().getMessage()
                    );

                } finally {

                    operacionEnCurso = false;

                    actualizarBotones(
                            esBibliotecario()
                            || idEstudianteSesion > 0
                    );
                }
            }
        };

        trabajador.execute();
    }

    private String buscarEstudiante(
            List<Estudiante> estudiantes, int id) {

        for (Estudiante estudiante : estudiantes) {

            if (estudiante.getId() == id) {
                return estudiante.getNombre();
            }
        }

        return String.valueOf(id);
    }

    private String buscarLibro(List<Libro> libros, int id) {

        for (Libro libro : libros) {

            if (libro.getId() == id) {
                return libro.getTitulo();
            }
        }

        return String.valueOf(id);
    }

    private void registrarPrestamo() {

        Estudiante estudiante =
                (Estudiante) comboEstudiante.getSelectedItem();

        Libro libro =
                (Libro) comboLibro.getSelectedItem();

        if (estudiante == null || libro == null) {

            mostrarError(
                    "Seleccione un estudiante y un libro."
            );

            return;
        }

        if (!esBibliotecario()
                && estudiante.getId() != idEstudianteSesion) {

            mostrarError(
                    "Solo puede registrar préstamos propios."
            );

            return;
        }

        if (libro.getStock() <= 0) {

            mostrarError(
                    "El libro no tiene stock disponible."
            );

            return;
        }

        actualizarBotones(false);

        controlador.registrarPrestamo(
                estudiante.getId(),
                libro.getId(),
                () -> {
                    actualizarBotones(true);
                    cargarDatos();
                }
        );
    }

    private void devolverLibro() {

        int filaVista = tablaPrestamos.getSelectedRow();

        if (filaVista == -1) {

            mostrarError(
                    "Seleccione un préstamo de la tabla."
            );

            return;
        }

        int fila = tablaPrestamos.convertRowIndexToModel(
                filaVista
        );

        int idPrestamo = Integer.parseInt(
                modeloTabla.getValueAt(fila, 0).toString()
        );

        String estado = modeloTabla.getValueAt(
                fila, 5
        ).toString();

        if ("Devuelto".equals(estado)) {

            mostrarError(
                    "Este préstamo ya fue devuelto."
            );

            return;
        }

        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "¿Desea registrar la devolución del préstamo "
                + idPrestamo + "?",
                "Confirmar devolución",
                JOptionPane.YES_NO_OPTION
        );

        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }

        actualizarBotones(false);

        controlador.devolverLibro(
                idPrestamo,
                esBibliotecario() ? 0 : idEstudianteSesion,
                () -> {
                    actualizarBotones(true);
                    cargarDatos();
                }
        );
    }

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Biblioteca Escolar",
                JOptionPane.WARNING_MESSAGE
        );
    }
}
