package vista;

import dao.UsuarioDAO;
import modelo.Usuario;
import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

public class VentanaLogin extends JFrame {
    private final JTextField correo = new JTextField();
    private final JPasswordField clave = new JPasswordField();
    private final JButton ingresar = new JButton("Ingresar");

    public VentanaLogin() {
        setTitle("Biblioteca Escolar - Ingreso");
        setSize(420, 240);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JPanel form = new JPanel(new GridLayout(2, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        form.add(new JLabel("Correo:"));
        form.add(correo);
        form.add(new JLabel("Contraseña:"));
        form.add(clave);
        add(new JLabel("BIBLIOTECA ESCOLAR", SwingConstants.CENTER), BorderLayout.NORTH);
        add(form, BorderLayout.CENTER);
        JPanel pie = new JPanel();
        pie.add(ingresar);
        add(pie, BorderLayout.SOUTH);
        ingresar.addActionListener(e -> entrar());
        clave.addActionListener(e -> entrar());
        setVisible(true);
    }

    private void entrar() {
        char[] chars = clave.getPassword();
        String password = new String(chars);
        Arrays.fill(chars, '\0');
        String email = correo.getText().trim();
        if (email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Complete los datos.");
            return;
        }
        ingresar.setEnabled(false);
        new SwingWorker<Usuario, Void>() {
            protected Usuario doInBackground() throws Exception {
                return new UsuarioDAO().iniciarSesion(email, password);
            }

            protected void done() {
                ingresar.setEnabled(true);
                try {
                    Usuario u = get();
                    if (u == null) {
                        JOptionPane.showMessageDialog(VentanaLogin.this, "Credenciales incorrectas.");
                        clave.setText("");
                    } else {
                        new VentanaPrincipal(u);
                        dispose();
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(VentanaLogin.this, "Error de conexión: " + ex.getMessage());
                }
            }
        }.execute();
    }
}
