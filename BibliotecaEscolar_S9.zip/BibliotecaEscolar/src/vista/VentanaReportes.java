package vista;

import dao.*;
import modelo.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.*;

public class VentanaReportes extends JFrame {
    private final Usuario usuario;
    private final ReporteDAO reportes = new ReporteDAO();
    private final EstudianteDAO estudiantes = new EstudianteDAO();
    private final JComboBox<String> tipo = new JComboBox<>(
            new String[] { "Libros más prestados", "Historial por estudiante", "Préstamos activos" });
    private final JComboBox<Estudiante> estudiante = new JComboBox<>();
    private final DefaultTableModel datos = new DefaultTableModel() {
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    };
    private final JTable tabla = new JTable(datos);

    public VentanaReportes(Usuario u) {
        usuario = u;
        setTitle("Reportes de biblioteca");
        setSize(900, 540);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JPanel filtros = new JPanel(new GridLayout(3, 2, 8, 8));
        filtros.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        filtros.add(new JLabel("Reporte:"));
        filtros.add(tipo);
        filtros.add(new JLabel("Estudiante:"));
        filtros.add(estudiante);
        JButton consultar = new JButton("Consultar");
        filtros.add(new JLabel());
        filtros.add(consultar);
        add(filtros, BorderLayout.NORTH);
        tabla.setAutoCreateRowSorter(true);
        add(new JScrollPane(tabla));
        boolean admin = admin();
        try {
            if (admin) {
                for (Estudiante e : estudiantes.listarTodos())
                    estudiante.addItem(e);
            } else {
                Estudiante e = estudiantes.buscarPorRut(u.getRut());
                if (e != null)
                    estudiante.addItem(e);
                tipo.removeItemAt(2);
            }
        } catch (Exception e) {
            error(e);
        }
        tipo.addActionListener(e -> actualizarFiltros());
        consultar.addActionListener(e -> consultar());
        actualizarFiltros();
        setVisible(true);
    }

    private boolean admin() {
        return "bibliotecario".equalsIgnoreCase(usuario.getRol());
    }

    private void actualizarFiltros() {
        estudiante.setEnabled(admin() && tipo.getSelectedIndex() == 1);
    }

    private void consultar() {
        try {
            java.util.List<Object[]> lista;
            String[] columnas;
            int indice = tipo.getSelectedIndex();
            if (indice == 0) {
                columnas = new String[] { "Título", "Autor", "Total préstamos" };
                lista = reportes.librosMasPrestados();
            } else if (indice == 1) {
                Estudiante e = (Estudiante) estudiante.getSelectedItem();
                if (e == null) {
                    JOptionPane.showMessageDialog(this, "No existe un estudiante asociado.");
                    return;
                }
                columnas = new String[] { "Libro", "Fecha préstamo", "Vencimiento", "Estado" };
                lista = reportes.historialPorEstudiante(e.getId());
            } else {
                if (!admin())
                    return;
                columnas = new String[] { "Estudiante", "Libro", "Fecha préstamo", "Vencimiento" };
                lista = reportes.prestamosActivos();
            }
            datos.setColumnIdentifiers(columnas);
            datos.setRowCount(0);
            for (Object[] fila : lista)
                datos.addRow(fila);
        } catch (Exception e) {
            error(e);
        }
    }

    private void error(Exception e) {
        JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
