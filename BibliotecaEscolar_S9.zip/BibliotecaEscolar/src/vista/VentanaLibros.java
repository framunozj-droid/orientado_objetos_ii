package vista;

import dao.*;
import modelo.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.*;

public class VentanaLibros extends JFrame {
    private final LibroDAO dao = new LibroDAO();
    private final CategoriaDAO categorias = new CategoriaDAO();
    private final JTextField titulo = new JTextField(), autor = new JTextField(), isbn = new JTextField(),
            editorial = new JTextField(), stock = new JTextField();
    private final JComboBox<Categoria> categoria = new JComboBox<>();
    private final DefaultTableModel datos = new DefaultTableModel(
            new String[] { "ID", "Título", "Autor", "ISBN", "Editorial", "Stock", "Categoría" }, 0) {
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    };
    private final JTable tabla = new JTable(datos);
    private int seleccionado = 0;

    public VentanaLibros() {
        setTitle("Gestión de libros");
        setSize(920, 590);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JPanel form = new JPanel(new GridLayout(6, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        String[] etiquetas = { "Título", "Autor", "ISBN", "Editorial", "Stock", "Categoría" };
        JComponent[] campos = { titulo, autor, isbn, editorial, stock, categoria };
        for (int i = 0; i < 6; i++) {
            form.add(new JLabel(etiquetas[i]));
            form.add(campos[i]);
        }
        JPanel botones = new JPanel();
        for (String nombre : new String[] { "Guardar", "Actualizar", "Eliminar", "Limpiar" }) {
            JButton b = new JButton(nombre);
            botones.add(b);
            b.addActionListener(e -> {
                switch (nombre) {
                    case "Guardar":
                        guardar(false);
                        break;
                    case "Actualizar":
                        guardar(true);
                        break;
                    case "Eliminar":
                        eliminar();
                        break;
                    default:
                        limpiar();
                }
            });
        }
        JPanel arriba = new JPanel(new BorderLayout());
        arriba.add(form);
        arriba.add(botones, BorderLayout.SOUTH);
        add(arriba, BorderLayout.NORTH);
        tabla.setAutoCreateRowSorter(true);
        add(new JScrollPane(tabla));
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting())
                seleccionar();
        });
        try {
            for (Categoria c : categorias.listarTodos())
                categoria.addItem(c);
        } catch (Exception e) {
            error(e);
        }
        cargar();
        setVisible(true);
    }

    private void cargar() {
        try {
            datos.setRowCount(0);
            for (Libro l : dao.listarTodos()) {
                String nombre = "";
                for (int i = 0; i < categoria.getItemCount(); i++)
                    if (categoria.getItemAt(i).getId() == l.getIdCategoria())
                        nombre = categoria.getItemAt(i).getNombre();
                datos.addRow(new Object[] { l.getId(), l.getTitulo(), l.getAutor(), l.getIsbn(), l.getEditorial(),
                        l.getStock(), nombre });
            }
        } catch (Exception e) {
            error(e);
        }
    }

    private void guardar(boolean actualizar) {
        try {
            if (actualizar && seleccionado == 0)
                throw new IllegalArgumentException("Seleccione un libro.");
            Categoria c = (Categoria) categoria.getSelectedItem();
            if (c == null || titulo.getText().trim().isEmpty() || autor.getText().trim().isEmpty()
                    || isbn.getText().trim().isEmpty() || editorial.getText().trim().isEmpty())
                throw new IllegalArgumentException("Complete los campos.");
            int cantidad = Integer.parseInt(stock.getText().trim());
            if (cantidad < 0)
                throw new IllegalArgumentException("Stock negativo.");
            Libro l = new Libro(seleccionado, titulo.getText().trim(), autor.getText().trim(), isbn.getText().trim(),
                    editorial.getText().trim(), cantidad, c.getId());
            boolean ok = actualizar ? dao.actualizar(l) : dao.guardar(l);
            if (ok) {
                cargar();
                limpiar();
            } else
                JOptionPane.showMessageDialog(this, "No se guardaron cambios.");
        } catch (Exception e) {
            error(e);
        }
    }

    private void eliminar() {
        if (seleccionado == 0)
            return;
        if (JOptionPane.showConfirmDialog(this, "¿Eliminar libro?", "Confirmar",
                JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION)
            return;
        try {
            dao.eliminar(seleccionado);
            cargar();
            limpiar();
        } catch (Exception e) {
            error(e);
        }
    }

    private void seleccionar() {
        int v = tabla.getSelectedRow();
        if (v < 0)
            return;
        int f = tabla.convertRowIndexToModel(v);
        seleccionado = (int) datos.getValueAt(f, 0);
        JTextField[] campos = { titulo, autor, isbn, editorial, stock };
        for (int i = 0; i < 5; i++)
            campos[i].setText(String.valueOf(datos.getValueAt(f, i + 1)));
        for (int i = 0; i < categoria.getItemCount(); i++)
            if (categoria.getItemAt(i).getNombre().equals(datos.getValueAt(f, 6)))
                categoria.setSelectedIndex(i);
    }

    private void limpiar() {
        seleccionado = 0;
        for (JTextField t : new JTextField[] { titulo, autor, isbn, editorial, stock })
            t.setText("");
        tabla.clearSelection();
    }

    private void error(Exception e) {
        JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
