
package controlador;

import dao.PrestamoDAO;

import javax.swing.*;
import java.util.concurrent.ExecutionException;

public class PrestamoControlador {

    private final PrestamoDAO prestamoDAO;

    public PrestamoControlador() {
        prestamoDAO = new PrestamoDAO();
    }

    public void registrarPrestamo(
            int idEstudiante,
            int idLibro,
            Runnable actualizarVista) {

        SwingWorker<Boolean, Void> trabajador =
                new SwingWorker<Boolean, Void>() {

            @Override
            protected Boolean doInBackground()
                    throws Exception {

                return prestamoDAO.registrarPrestamo(
                        idEstudiante,
                        idLibro
                );
            }

            @Override
            protected void done() {

                try {

                    boolean registrado = get();

                    if (registrado) {

                        JOptionPane.showMessageDialog(
                                null,
                                "Préstamo registrado correctamente."
                        );

                    } else {

                        JOptionPane.showMessageDialog(
                                null,
                                "No hay stock disponible."
                        );
                    }

                } catch (InterruptedException e) {

                    Thread.currentThread().interrupt();

                    JOptionPane.showMessageDialog(
                            null,
                            "Operación interrumpida."
                    );

                } catch (ExecutionException e) {

                    JOptionPane.showMessageDialog(
                            null,
                            "Error al registrar préstamo: "
                            + e.getCause().getMessage()
                    );

                } finally {

                    if (actualizarVista != null) {
                        actualizarVista.run();
                    }
                }
            }
        };

        trabajador.execute();
    }

    public void devolverLibro(
            int idPrestamo,
            int idEstudianteAutorizado,
            Runnable actualizarVista) {

        SwingWorker<Boolean, Void> trabajador =
                new SwingWorker<Boolean, Void>() {

            @Override
            protected Boolean doInBackground()
                    throws Exception {

                return prestamoDAO.devolverLibro(idPrestamo, idEstudianteAutorizado);
            }

            @Override
            protected void done() {

                try {

                    boolean devuelto = get();

                    if (devuelto) {

                        JOptionPane.showMessageDialog(
                                null,
                                "Devolución registrada correctamente."
                        );

                    } else {

                        JOptionPane.showMessageDialog(
                                null,
                                "El préstamo ya fue devuelto "
                                + "o no existe."
                        );
                    }

                } catch (InterruptedException e) {

                    Thread.currentThread().interrupt();

                    JOptionPane.showMessageDialog(
                            null,
                            "Operación interrumpida."
                    );

                } catch (ExecutionException e) {

                    JOptionPane.showMessageDialog(
                            null,
                            "Error al registrar devolución: "
                            + e.getCause().getMessage()
                    );

                } finally {

                    if (actualizarVista != null) {
                        actualizarVista.run();
                    }
                }
            }
        };

        trabajador.execute();
    }
}
