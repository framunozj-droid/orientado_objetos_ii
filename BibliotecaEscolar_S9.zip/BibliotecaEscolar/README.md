# Sistema de Biblioteca Escolar

**Asignatura:** Desarrollo Orientado a Objetos II  
**Evaluación:** Examen Final Transversal – Semana 9  
**Institución:** Duoc UC

## Descripción

Aplicación de escritorio desarrollada en Java para administrar una biblioteca escolar. Permite gestionar libros, estudiantes, categorías, préstamos y devoluciones, manteniendo la información almacenada en una base de datos MySQL.

El sistema cuenta con inicio de sesión y diferentes permisos según el tipo de usuario.

## Tecnologías utilizadas

- Java JDK 21
- Java Swing (JFrame)
- MySQL
- JDBC (MySQL Connector/J)
- Visual Studio Code

## Funcionalidades

- Inicio de sesión para bibliotecarios y estudiantes.
- Registro, modificación, eliminación y consulta de libros.
- Administración de estudiantes y categorías.
- Registro de préstamos y devoluciones.
- Actualización del stock de libros.
- Consulta de préstamos activos y atrasados.
- Reportes de libros más prestados e historial de estudiantes.
- Control de acceso según el rol del usuario.

## Estructura del proyecto

```text
BibliotecaEscolar/
├── src/
│   ├── app/
│   ├── conexion/
│   ├── controlador/
│   ├── dao/
│   ├── modelo/
│   └── vista/
├── lib/
│   └── mysql-connector-j-9.x.x.jar
├── sql/
│   ├── PRY2203_EFT_S9_Script_crea_tablas_biblioteca.sql
│   └── PRY2203_EFT_S9_Script_poblado_tablas_biblioteca.sql
├── out/
│   └── BibliotecaEscolar.jar
├── bin/
└── README.md
```

## Base de datos

La aplicación utiliza una base de datos MySQL llamada `biblioteca`.

Para configurarla:

1. Iniciar MySQL Server.
2. Ejecutar `PRY2203_EFT_S9_Script_crea_tablas_biblioteca.sql`.
3. Ejecutar `PRY2203_EFT_S9_Script_poblado_tablas_biblioteca.sql`.
4. Verificar que se hayan creado las tablas `usuarios`, `estudiantes`, `categorias`, `libros` y `prestamos`.

El script de poblamiento incluye datos iniciales para probar el funcionamiento del sistema.

## Configuración de conexión

La conexión se encuentra definida en:

`src/conexion/DatabaseConnection.java`

Se deben configurar los datos correspondientes al servidor MySQL local:

- Servidor: `localhost`
- Puerto: `3306`
- Base de datos: `biblioteca`
- Usuario: el configurado en MySQL
- Contraseña: la correspondiente al usuario de MySQL

No se deben publicar contraseñas personales en el repositorio.

## Compilación y ejecución

Desde la carpeta principal del proyecto, abrir una terminal PowerShell.

**Compilar:**

```powershell
New-Item -ItemType Directory -Force bin | Out-Null

javac -encoding UTF-8 -cp "lib/*" -d bin src\modelo\*.java src\conexion\*.java src\dao\*.java src\controlador\*.java src\vista\*.java src\app\*.java
```

**Ejecutar desde las clases compiladas:**

```powershell
java -cp "bin;lib/*" app.Main
```

**Generar el archivo JAR dentro de la carpeta out:**

```powershell
New-Item -ItemType Directory -Force out | Out-Null

& "C:\Program Files\Java\jdk-21.0.10\bin\jar.exe" --create --file out/BibliotecaEscolar.jar --main-class app.Main -C bin .
```

**Ejecutar desde el JAR:**

```powershell
java -cp "out/BibliotecaEscolar.jar;lib/*" app.Main
```

Para ejecutar el proyecto es necesario contar con MySQL Server funcionando y el conector JDBC dentro de la carpeta `lib`.

## Usuarios de prueba

| Rol | Correo | Contraseña |
|---|---|---|
| Bibliotecario | antonia@correo.cl | clave123 |
| Estudiante | carlos@correo.cl | clave123 |

Estas cuentas corresponden a los datos de prueba proporcionados para la actividad.

## Programación orientada a objetos

El proyecto utiliza clases, objetos, encapsulamiento, herencia, polimorfismo, clases abstractas e interfaces.

También incorpora los patrones MVC, DAO y Singleton para organizar el código y separar las responsabilidades de cada componente.

Las operaciones de préstamo y devolución utilizan transacciones JDBC y sincronización para mantener la consistencia del stock. Se utiliza `SwingWorker` para ejecutar operaciones en segundo plano y evitar que la interfaz se bloquee.

## Consideraciones

- La aplicación requiere conexión activa con MySQL.
- Los registros iniciales corresponden a los scripts de la actividad.
- El archivo ejecutable se encuentra en `out/BibliotecaEscolar.jar`.
- El archivo JAR necesita el conector MySQL Connector/J ubicado en `lib`.
- Los datos de acceso incluidos en los scripts son únicamente para pruebas académicas.
- Para ejecutar el proyecto en otro computador, se debe configurar previamente la base de datos y la conexión MySQL.