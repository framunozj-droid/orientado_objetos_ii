package model;

public class PedidoEncomienda extends Pedido {

    private double peso;
    private boolean embalajeCorrecto;

    public PedidoEncomienda() {
        super();
        this.peso = 0;
        this.embalajeCorrecto = false;
    }

    public PedidoEncomienda(int idPedido, String direccionEntrega, String tipoPedido, double peso, boolean embalajeCorrecto) {
        super(idPedido, direccionEntrega, tipoPedido);
        this.peso = peso;
        this.embalajeCorrecto = embalajeCorrecto;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public boolean getEmbalajeCorrecto() {
        return embalajeCorrecto;
    }

    public void setEmbalajeCorrecto(boolean embalajeCorrecto) {
        this.embalajeCorrecto = embalajeCorrecto;
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("[Pedido Encomienda]");
        System.out.println("Asignando repartidor...");

        if (peso > 0 && embalajeCorrecto == true) {
            System.out.println("Validando peso y embalaje... OK");
        } else {
            System.out.println("No se puede asignar. Revisar peso o embalaje.");
        }
    }

    @Override
    public void asignarRepartidor(String nombreRepartidor) {
        System.out.println("Pedido asignado a " + nombreRepartidor);
    }
}