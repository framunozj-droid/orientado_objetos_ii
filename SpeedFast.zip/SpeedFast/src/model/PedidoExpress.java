package model;

public class PedidoExpress extends Pedido {

    private boolean disponibilidadInmediata;

    public PedidoExpress() {
        super();
        this.disponibilidadInmediata = false;
    }

    public PedidoExpress(int idPedido, String direccionEntrega, String tipoPedido, boolean disponibilidadInmediata) {
        super(idPedido, direccionEntrega, tipoPedido);
        this.disponibilidadInmediata = disponibilidadInmediata;
    }

    public boolean getDisponibilidadInmediata() {
        return disponibilidadInmediata;
    }

    public void setDisponibilidadInmediata(boolean disponibilidadInmediata) {
        this.disponibilidadInmediata = disponibilidadInmediata;
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("[Pedido Express]");
        System.out.println("Asignando repartidor...");

        if (disponibilidadInmediata == true) {
            System.out.println("Repartidor más cercano con disponibilidad inmediata encontrado.");
        } else {
            System.out.println("No hay repartidor disponible en este momento.");
        }
    }

    @Override
    public void asignarRepartidor(String nombreRepartidor) {
        System.out.println("Pedido asignado a " + nombreRepartidor);
    }
}