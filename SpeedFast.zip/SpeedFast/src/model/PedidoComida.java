package model;

public class PedidoComida extends Pedido {

    private boolean mochilaTermica;

    public PedidoComida() {
        super();
        this.mochilaTermica = false;
    }

    public PedidoComida(int idPedido, String direccionEntrega, String tipoPedido, boolean mochilaTermica) {
        super(idPedido, direccionEntrega, tipoPedido);
        this.mochilaTermica = mochilaTermica;
    }

    public boolean getMochilaTermica() {
        return mochilaTermica;
    }

    public void setMochilaTermica(boolean mochilaTermica) {
        this.mochilaTermica = mochilaTermica;
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("[Pedido Comida]");
        System.out.println("Asignando repartidor...");

        if (mochilaTermica == true) {
            System.out.println("Verificando mochila térmica... OK");
        } else {
            System.out.println("No se puede asignar. Falta mochila térmica.");
        }
    }

    @Override
    public void asignarRepartidor(String nombreRepartidor) {
        System.out.println("Pedido asignado a " + nombreRepartidor);
    }
}