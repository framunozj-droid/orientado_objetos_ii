package app;

import model.PedidoComida;
import model.PedidoEncomienda;
import model.PedidoExpress;

public class Main {

    public static void main(String[] args) {

        PedidoComida pedidoComida = new PedidoComida(
                1,
                "Av. Central 123",
                "Comida",
                true
        );

        PedidoEncomienda pedidoEncomienda = new PedidoEncomienda(
                2,
                "Los Robles 456",
                "Encomienda",
                5.5,
                true
        );

        PedidoExpress pedidoExpress = new PedidoExpress(
                3,
                "Pasaje Norte 789",
                "Express",
                true
        );

        pedidoComida.asignarRepartidor();
        pedidoComida.asignarRepartidor("Juan Pérez");

        System.out.println();

        pedidoEncomienda.asignarRepartidor();
        pedidoEncomienda.asignarRepartidor("Camila Soto");

        System.out.println();

        pedidoExpress.asignarRepartidor();
        pedidoExpress.asignarRepartidor("Luis Díaz");
    }
}