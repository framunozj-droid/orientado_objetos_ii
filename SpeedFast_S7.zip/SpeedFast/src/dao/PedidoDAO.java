package dao;

import model.Pedido;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    public boolean guardar(Pedido pedido) {

        String sql =
                "INSERT INTO pedido "
                + "(direccion, tipo, estado) "
                + "VALUES (?, ?, ?)";

        try (
                Connection conexion = ConexionBD.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql)
        ) {

            sentencia.setString(
                    1,
                    pedido.getDireccion()
            );

            sentencia.setString(
                    2,
                    pedido.getTipo()
            );

            sentencia.setString(
                    3,
                    pedido.getEstado()
            );

            sentencia.executeUpdate();

            return true;

        } catch (SQLException e) {

            System.out.println(
                    "Error al guardar pedido: "
                    + e.getMessage()
            );

            return false;
        }
    }

    public List<Pedido> listarTodos() {

        List<Pedido> pedidos =
                new ArrayList<>();

        String sql =
                "SELECT id, direccion, tipo, estado "
                + "FROM pedido "
                + "ORDER BY id";

        try (
                Connection conexion = ConexionBD.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql);
                ResultSet resultado =
                        sentencia.executeQuery()
        ) {

            while (resultado.next()) {

                Pedido pedido = new Pedido(
                        resultado.getInt("id"),
                        resultado.getString("direccion"),
                        resultado.getString("tipo"),
                        resultado.getString("estado")
                );

                pedidos.add(pedido);
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error al listar pedidos: "
                    + e.getMessage()
            );
        }

        return pedidos;
    }

    public boolean cambiarEstado(
            int idPedido,
            String estado) {

        String sql =
                "UPDATE pedido "
                + "SET estado = ? "
                + "WHERE id = ?";

        try (
                Connection conexion = ConexionBD.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql)
        ) {

            sentencia.setString(1, estado);
            sentencia.setInt(2, idPedido);

            sentencia.executeUpdate();

            return true;

        } catch (SQLException e) {

            System.out.println(
                    "Error al cambiar estado: "
                    + e.getMessage()
            );

            return false;
        }
    }
}