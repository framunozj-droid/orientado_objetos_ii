package vista;

import dao.PedidoDAO;
import model.Pedido;

import javax.swing.*;
import java.awt.*;

public class VentanaRegistroPedido extends JFrame {

    private JTextField campoDireccion;
    private JComboBox<String> comboTipo;
    private JButton botonGuardar;

    public VentanaRegistroPedido() {

        setTitle("Registrar Pedido");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        crearComponentes();

        setVisible(true);
    }

    private void crearComponentes() {

        JLabel titulo = new JLabel(
                "REGISTRAR PEDIDO",
                SwingConstants.CENTER
        );

        titulo.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        17
                )
        );

        campoDireccion =
                new JTextField();

        String[] tipos = {
                "COMIDA",
                "ENCOMIENDA",
                "EXPRESS"
        };

        comboTipo =
                new JComboBox<>(tipos);

        botonGuardar =
                new JButton("Guardar");

        JPanel formulario =
                new JPanel(
                        new GridLayout(
                                3,
                                2,
                                10,
                                10
                        )
                );

        formulario.setBorder(
                BorderFactory.createEmptyBorder(
                        25,
                        30,
                        25,
                        30
                )
        );

        formulario.add(
                new JLabel("Dirección:")
        );

        formulario.add(campoDireccion);

        formulario.add(
                new JLabel("Tipo:")
        );

        formulario.add(comboTipo);

        formulario.add(new JLabel(""));
        formulario.add(botonGuardar);

        setLayout(new BorderLayout());

        add(titulo, BorderLayout.NORTH);
        add(formulario, BorderLayout.CENTER);

        botonGuardar.addActionListener(
                e -> guardarPedido()
        );
    }

    private void guardarPedido() {

        String direccion =
                campoDireccion
                        .getText()
                        .trim();

        if (direccion.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Debe ingresar una dirección."
            );

            return;
        }

        String tipo =
                comboTipo
                        .getSelectedItem()
                        .toString();

        Pedido pedido =
                new Pedido(
                        direccion,
                        tipo
                );

        PedidoDAO pedidoDAO =
                new PedidoDAO();

        if (pedidoDAO.guardar(pedido)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Pedido guardado correctamente."
            );

            campoDireccion.setText("");

            comboTipo.setSelectedIndex(0);

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible guardar el pedido."
            );
        }
    }
}