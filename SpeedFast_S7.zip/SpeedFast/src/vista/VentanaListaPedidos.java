package vista;

import dao.PedidoDAO;
import model.Pedido;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.util.List;

public class VentanaListaPedidos extends JFrame {

    private JTable tablaPedidos;
    private DefaultTableModel modeloTabla;
    private JButton botonActualizar;

    public VentanaListaPedidos() {

        setTitle("Listado de Pedidos");
        setSize(650, 400);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        crearComponentes();
        cargarPedidos();

        setVisible(true);
    }

    private void crearComponentes() {

        String[] columnas = {
                "ID",
                "Dirección",
                "Tipo",
                "Estado"
        };

        modeloTabla =
                new DefaultTableModel(
                        columnas,
                        0
                );

        tablaPedidos =
                new JTable(modeloTabla);

        JScrollPane panelTabla =
                new JScrollPane(tablaPedidos);

        botonActualizar =
                new JButton("Actualizar");

        JPanel panelInferior =
                new JPanel();

        panelInferior.add(
                botonActualizar
        );

        setLayout(new BorderLayout());

        add(
                panelTabla,
                BorderLayout.CENTER
        );

        add(
                panelInferior,
                BorderLayout.SOUTH
        );

        botonActualizar.addActionListener(
                e -> cargarPedidos()
        );
    }

    private void cargarPedidos() {

        modeloTabla.setRowCount(0);

        PedidoDAO pedidoDAO =
                new PedidoDAO();

        List<Pedido> pedidos =
                pedidoDAO.listarTodos();

        for (Pedido pedido : pedidos) {

            Object[] fila = {
                    pedido.getId(),
                    pedido.getDireccion(),
                    pedido.getTipo(),
                    pedido.getEstado()
            };

            modeloTabla.addRow(fila);
        }
    }
}