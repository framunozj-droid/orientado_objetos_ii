package vista;

import dao.RepartidorDAO;
import model.Repartidor;

import javax.swing.*;
import java.awt.*;

public class VentanaRegistroRepartidor extends JFrame {

    private JTextField campoNombre;
    private JButton botonGuardar;

    public VentanaRegistroRepartidor() {

        setTitle("Registrar Repartidor");
        setSize(400, 220);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        crearComponentes();

        setVisible(true);
    }

    private void crearComponentes() {

        JLabel titulo = new JLabel(
                "REGISTRAR REPARTIDOR",
                SwingConstants.CENTER
        );

        titulo.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        17
                )
        );

        campoNombre = new JTextField();

        botonGuardar =
                new JButton("Guardar");

        JPanel formulario =
                new JPanel(
                        new GridLayout(
                                2,
                                2,
                                10,
                                10
                        )
                );

        formulario.setBorder(
                BorderFactory.createEmptyBorder(
                        30,
                        30,
                        30,
                        30
                )
        );

        formulario.add(
                new JLabel("Nombre:")
        );

        formulario.add(campoNombre);

        formulario.add(new JLabel(""));
        formulario.add(botonGuardar);

        setLayout(new BorderLayout());

        add(titulo, BorderLayout.NORTH);
        add(formulario, BorderLayout.CENTER);

        botonGuardar.addActionListener(
                e -> guardarRepartidor()
        );
    }

    private void guardarRepartidor() {

        String nombre =
                campoNombre
                        .getText()
                        .trim();

        if (nombre.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Debe ingresar el nombre del repartidor."
            );

            return;
        }

        Repartidor repartidor =
                new Repartidor();

        repartidor.setNombre(nombre);

        RepartidorDAO repartidorDAO =
                new RepartidorDAO();

        boolean guardado =
                repartidorDAO.guardar(repartidor);

        if (guardado) {

            JOptionPane.showMessageDialog(
                    this,
                    "Repartidor registrado correctamente."
            );

            campoNombre.setText("");

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible registrar el repartidor."
            );
        }
    }
}