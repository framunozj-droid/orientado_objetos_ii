package vista;

import dao.EntregaDAO;
import dao.PedidoDAO;
import dao.RepartidorDAO;

import model.Entrega;
import model.Pedido;
import model.Repartidor;

import javax.swing.*;
import java.awt.*;

import java.sql.Date;
import java.sql.Time;

import java.time.LocalDate;
import java.time.LocalTime;

import java.util.List;

public class VentanaEntrega extends JFrame {

    private JComboBox<Pedido> comboPedidos;
    private JComboBox<Repartidor> comboRepartidores;
    private JButton botonIniciar;

    public VentanaEntrega() {

        setTitle("Asignar Repartidor");
        setSize(500, 280);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        crearComponentes();
        cargarPedidos();
        cargarRepartidores();

        setVisible(true);
    }

    private void crearComponentes() {

        JLabel titulo = new JLabel(
                "ASIGNAR REPARTIDOR",
                SwingConstants.CENTER
        );

        titulo.setFont(
                new Font("Arial", Font.BOLD, 17)
        );

        comboPedidos = new JComboBox<>();
        comboRepartidores = new JComboBox<>();

        botonIniciar = new JButton(
                "Iniciar entrega"
        );

        JPanel formulario = new JPanel(
                new GridLayout(3, 2, 10, 10)
        );

        formulario.setBorder(
                BorderFactory.createEmptyBorder(
                        30,
                        30,
                        30,
                        30
                )
        );

        formulario.add(
                new JLabel("Pedido:")
        );

        formulario.add(comboPedidos);

        formulario.add(
                new JLabel("Repartidor:")
        );

        formulario.add(comboRepartidores);

        formulario.add(new JLabel(""));
        formulario.add(botonIniciar);

        setLayout(new BorderLayout());

        add(titulo, BorderLayout.NORTH);
        add(formulario, BorderLayout.CENTER);

        botonIniciar.addActionListener(
                e -> iniciarEntrega()
        );
    }

    private void cargarPedidos() {

        comboPedidos.removeAllItems();

        PedidoDAO pedidoDAO = new PedidoDAO();

        List<Pedido> pedidos =
                pedidoDAO.listarTodos();

        for (Pedido pedido : pedidos) {

            if (pedido.getEstado().equals("PENDIENTE")) {

                comboPedidos.addItem(pedido);
            }
        }
    }

    private void cargarRepartidores() {

        comboRepartidores.removeAllItems();

        RepartidorDAO repartidorDAO =
                new RepartidorDAO();

        List<Repartidor> repartidores =
                repartidorDAO.listarTodos();

        for (Repartidor repartidor : repartidores) {

            comboRepartidores.addItem(repartidor);
        }
    }

    private void iniciarEntrega() {

        Pedido pedido =
                (Pedido) comboPedidos.getSelectedItem();

        Repartidor repartidor =
                (Repartidor) comboRepartidores.getSelectedItem();

        if (pedido == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "No hay pedidos pendientes."
            );

            return;
        }

        if (repartidor == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "No hay repartidores disponibles."
            );

            return;
        }

        Date fecha = Date.valueOf(
                LocalDate.now()
        );

        Time hora = Time.valueOf(
                LocalTime.now()
        );

        Entrega entrega = new Entrega(
                pedido.getId(),
                repartidor.getId(),
                fecha,
                hora
        );

        EntregaDAO entregaDAO =
                new EntregaDAO();

        boolean guardado =
                entregaDAO.guardar(entrega);

        if (guardado) {

            PedidoDAO pedidoDAO =
                    new PedidoDAO();

            pedidoDAO.cambiarEstado(
                    pedido.getId(),
                    "EN_REPARTO"
            );

            JOptionPane.showMessageDialog(
                    this,
                    "Entrega iniciada correctamente.\n"
                    + "Pedido: " + pedido.getId()
                    + "\nRepartidor: "
                    + repartidor.getNombre()
            );

            cargarPedidos();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible iniciar la entrega."
            );
        }
    }
}