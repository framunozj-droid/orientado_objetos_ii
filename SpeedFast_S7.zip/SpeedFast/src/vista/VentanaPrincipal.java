package vista;

import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {

    private JButton botonRegistrarPedido;
    private JButton botonRegistrarRepartidor;
    private JButton botonListar;
    private JButton botonEntrega;

    public VentanaPrincipal() {

        setTitle("SpeedFast - Gestión de Entregas");
        setSize(500, 380);

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setLocationRelativeTo(null);

        crearComponentes();

        setVisible(true);
    }

    private void crearComponentes() {

        JLabel titulo = new JLabel(
                "SPEEDFAST - GESTIÓN DE ENTREGAS",
                SwingConstants.CENTER
        );

        titulo.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        botonRegistrarPedido =
                new JButton("Registrar pedido");

        botonRegistrarRepartidor =
                new JButton("Registrar repartidor");

        botonListar =
                new JButton("Listar pedidos");

        botonEntrega =
                new JButton(
                        "Asignar repartidor / Iniciar entrega"
                );

        JPanel panelBotones =
                new JPanel(
                        new GridLayout(
                                4,
                                1,
                                10,
                                10
                        )
                );

        panelBotones.setBorder(
                BorderFactory.createEmptyBorder(
                        35,
                        60,
                        35,
                        60
                )
        );

        panelBotones.add(
                botonRegistrarPedido
        );

        panelBotones.add(
                botonRegistrarRepartidor
        );

        panelBotones.add(
                botonListar
        );

        panelBotones.add(
                botonEntrega
        );

        setLayout(new BorderLayout());

        add(titulo, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);


        botonRegistrarPedido.addActionListener(
                e -> new VentanaRegistroPedido()
        );

        botonRegistrarRepartidor.addActionListener(
                e -> new VentanaRegistroRepartidor()
        );

        botonListar.addActionListener(
                e -> new VentanaListaPedidos()
        );

        botonEntrega.addActionListener(
                e -> new VentanaEntrega()
        );
    }
}