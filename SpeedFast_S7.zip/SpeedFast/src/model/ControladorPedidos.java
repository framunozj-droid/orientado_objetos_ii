package model;

import java.util.ArrayList;

public class ControladorPedidos {

    private static ArrayList<Pedido> listaPedidos = new ArrayList<>();

    public static void agregarPedido(Pedido pedido) {
        listaPedidos.add(pedido);
    }

    public static ArrayList<Pedido> obtenerPedidos() {
        return listaPedidos;
    }

    public static boolean existePedido(int id) {

        for (Pedido pedido : listaPedidos) {

            if (pedido.getId() == id) {
                return true;
            }
        }

        return false;
    }

public static Pedido buscarPedido(int id) {

    for (Pedido pedido : listaPedidos) {

        if (pedido.getId() == id) {
            return pedido;
        }
    }

    return null;
}

}