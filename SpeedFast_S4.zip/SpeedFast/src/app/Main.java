package app;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import model.PedidoComida;
import model.PedidoEncomienda;
import model.PedidoExpress;
import model.Repartidor;

public class Main {

    public static void main(String[] args) {

        // Pedidos de Camila
        PedidoComida pedido1 = new PedidoComida(
                101,
                "Av. Italia 456",
                4
        );

        PedidoExpress pedido2 = new PedidoExpress(
                102,
                "Av. Apoquindo 1500",
                7
        );

        // Pedidos de Luis
        PedidoEncomienda pedido3 = new PedidoEncomienda(
                103,
                "Av. Santa Rosa 567",
                6
        );

        PedidoComida pedido4 = new PedidoComida(
                104,
                "Los Alerces 245",
                3
        );

        // Pedidos de Daniela
        PedidoExpress pedido5 = new PedidoExpress(
                105,
                "Av. Providencia 890",
                8
        );

        PedidoEncomienda pedido6 = new PedidoEncomienda(
                106,
                "Los Robles 123",
                5
        );

        // Se crean los repartidores
        Repartidor camila = new Repartidor("Camila");
        Repartidor luis = new Repartidor("Luis");
        Repartidor daniela = new Repartidor("Daniela");

        // Se asignan los pedidos
        camila.agregarPedido(pedido1);
        camila.agregarPedido(pedido2);

        luis.agregarPedido(pedido3);
        luis.agregarPedido(pedido4);

        daniela.agregarPedido(pedido5);
        daniela.agregarPedido(pedido6);

        System.out.println("SPEEDFAST - INICIO DE ENTREGAS");
        System.out.println("--------------------------------");
        System.out.println();

        // Se crea un grupo de tres hilos
        ExecutorService ejecutor = Executors.newFixedThreadPool(3);

        // Cada repartidor se ejecuta al mismo tiempo
        ejecutor.execute(camila);
        ejecutor.execute(luis);
        ejecutor.execute(daniela);

        // No se aceptan nuevas tareas
        ejecutor.shutdown();

        try {

            // Espera hasta que todos terminen
            ejecutor.awaitTermination(1, TimeUnit.MINUTES);

        } catch (InterruptedException error) {

            System.out.println("La ejecución fue interrumpida.");
        }

        System.out.println();
        System.out.println("--------------------------------");
        System.out.println("TODAS LAS ENTREGAS FINALIZARON");
    }
}