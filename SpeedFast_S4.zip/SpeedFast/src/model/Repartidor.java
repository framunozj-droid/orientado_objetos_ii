package model;

import java.util.ArrayList;
import java.util.Random;

public class Repartidor implements Runnable {

    private String nombre;
    private ArrayList<Pedido> listaPedidos;

    public Repartidor(String nombre) {
        this.nombre = nombre;
        this.listaPedidos = new ArrayList<Pedido>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Pedido> getListaPedidos() {
        return listaPedidos;
    }

    public void agregarPedido(Pedido pedido) {
        listaPedidos.add(pedido);
    }

    @Override
    public void run() {

        Random aleatorio = new Random();

        for (Pedido pedido : listaPedidos) {

            try {

                System.out.println(
                        "[Repartidor: " + nombre + "] Entregando "
                                + pedido.getClass().getSimpleName()
                                + " #" + pedido.getIdPedido() + "..."
                );

                int tiempoEspera = aleatorio.nextInt(2000) + 1000;

                Thread.sleep(tiempoEspera);

                System.out.println(
                        "[Repartidor: " + nombre + "] Pedido #"
                                + pedido.getIdPedido()
                                + " entregado."
                );

            } catch (InterruptedException error) {

                System.out.println(
                        "La entrega del repartidor "
                                + nombre
                                + " fue interrumpida."
                );
            }
        }

        System.out.println(
                "[Repartidor: " + nombre + "] Terminó todas sus entregas."
        );
    }
}