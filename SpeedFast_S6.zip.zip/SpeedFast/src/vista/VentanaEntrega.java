package vista;

import model.ControladorPedidos;
import model.Pedido;

import javax.swing.*;
import java.awt.*;

public class VentanaEntrega extends JFrame {

    private JComboBox<String> comboPedidos;
    private JComboBox<String> comboRepartidores;
    private JButton botonIniciar;

    public VentanaEntrega() {

        setTitle("Asignar Repartidor");
        setSize(450, 280);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        crearComponentes();
        cargarPedidos();

        setVisible(true);
    }

    private void crearComponentes() {

        JLabel titulo = new JLabel(
                "ASIGNAR REPARTIDOR",
                SwingConstants.CENTER
        );

        titulo.setFont(
                new Font("Arial", Font.BOLD, 17)
        );

        comboPedidos = new JComboBox<>();

        String[] repartidores = {
                "Juan",
                "Camila",
                "Pedro"
        };

        comboRepartidores =
                new JComboBox<>(repartidores);

        botonIniciar =
                new JButton("Iniciar entrega");

        JPanel formulario = new JPanel(
                new GridLayout(3, 2, 10, 10)
        );

        formulario.setBorder(
                BorderFactory.createEmptyBorder(
                        30,
                        30,
                        30,
                        30
                )
        );

        formulario.add(
                new JLabel("Pedido:")
        );

        formulario.add(comboPedidos);

        formulario.add(
                new JLabel("Repartidor:")
        );

        formulario.add(comboRepartidores);

        formulario.add(new JLabel(""));
        formulario.add(botonIniciar);

        setLayout(new BorderLayout());

        add(titulo, BorderLayout.NORTH);
        add(formulario, BorderLayout.CENTER);

        botonIniciar.addActionListener(e -> {
            iniciarEntrega();
        });
    }

    private void cargarPedidos() {

        comboPedidos.removeAllItems();

        for (Pedido pedido :
                ControladorPedidos.obtenerPedidos()) {

            if (pedido.getEstado().equals("Pendiente")) {

                comboPedidos.addItem(
                        pedido.getId()
                        + " - "
                        + pedido.getDireccion()
                );
            }
        }
    }

    private void iniciarEntrega() {

        if (comboPedidos.getSelectedItem() == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "No hay pedidos pendientes."
            );

            return;
        }

        String pedidoSeleccionado =
                comboPedidos.getSelectedItem().toString();

        String repartidor =
                comboRepartidores
                        .getSelectedItem()
                        .toString();

        String[] partes =
                pedidoSeleccionado.split(" - ");

        int idPedido =
                Integer.parseInt(partes[0]);

        Pedido pedido =
                ControladorPedidos.buscarPedido(idPedido);

        if (pedido != null) {

            pedido.setEstado("En reparto");
            pedido.setRepartidor(repartidor);
            
            JOptionPane.showMessageDialog(
                    this,
                    "Pedido #" + pedido.getId()
                    + " asignado a "
                    + repartidor
                    + ".\nEntrega iniciada correctamente."
            );

            cargarPedidos();
        }
    }
}