package vista;

import model.ControladorPedidos;
import model.Pedido;

import javax.swing.*;
import java.awt.*;

public class VentanaRegistroPedido extends JFrame {

    private JTextField campoId;
    private JTextField campoDireccion;
    private JComboBox<String> comboTipo;
    private JButton botonGuardar;

    public VentanaRegistroPedido() {

        setTitle("Registrar Pedido");
        setSize(400, 280);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        crearComponentes();

        setVisible(true);
    }

    private void crearComponentes() {

        JLabel titulo = new JLabel(
                "REGISTRAR PEDIDO",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 17));

        campoId = new JTextField();
        campoDireccion = new JTextField();

        String[] tipos = {
                "Comida",
                "Encomienda",
                "Express"
        };

        comboTipo = new JComboBox<>(tipos);

        botonGuardar = new JButton("Guardar");

        JPanel formulario = new JPanel(
                new GridLayout(4, 2, 10, 10)
        );

        formulario.setBorder(
                BorderFactory.createEmptyBorder(20, 30, 20, 30)
        );

        formulario.add(new JLabel("ID:"));
        formulario.add(campoId);

        formulario.add(new JLabel("Dirección:"));
        formulario.add(campoDireccion);

        formulario.add(new JLabel("Tipo:"));
        formulario.add(comboTipo);

        formulario.add(new JLabel(""));
        formulario.add(botonGuardar);

        setLayout(new BorderLayout());

        add(titulo, BorderLayout.NORTH);
        add(formulario, BorderLayout.CENTER);

        botonGuardar.addActionListener(e -> guardarPedido());
    }

    private void guardarPedido() {

        String textoId = campoId.getText().trim();
        String direccion = campoDireccion.getText().trim();

        if (textoId.isEmpty() || direccion.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Debe completar todos los campos."
            );

            return;
        }

        int id;

        try {

            id = Integer.parseInt(textoId);

        } catch (NumberFormatException error) {

            JOptionPane.showMessageDialog(
                    this,
                    "El ID debe ser un número."
            );

            return;
        }

        if (ControladorPedidos.existePedido(id)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Ya existe un pedido con ese ID."
            );

            return;
        }

        String tipo = comboTipo.getSelectedItem().toString();

        Pedido pedido = new Pedido(
                id,
                direccion,
                tipo
        );

        ControladorPedidos.agregarPedido(pedido);

        JOptionPane.showMessageDialog(
                this,
                "Pedido registrado correctamente."
        );

        campoId.setText("");
        campoDireccion.setText("");
        comboTipo.setSelectedIndex(0);
    }
}