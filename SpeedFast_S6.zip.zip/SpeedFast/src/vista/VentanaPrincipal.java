package vista;

import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {

    private JButton botonRegistrar;
    private JButton botonListar;
    private JButton botonEntrega;

    public VentanaPrincipal() {

        setTitle("SpeedFast - Gestión de Entregas");
        setSize(450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        crearComponentes();

        setVisible(true);
    }

    private void crearComponentes() {

        JLabel titulo = new JLabel(
                "SPEEDFAST - GESTIÓN DE ENTREGAS",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 18));

        botonRegistrar = new JButton("Registrar pedido");
        botonListar = new JButton("Listar pedidos");
        botonEntrega = new JButton("Asignar repartidor / Iniciar entrega");

        JPanel panelBotones = new JPanel();

        panelBotones.setLayout(
                new GridLayout(3, 1, 10, 10)
        );

        panelBotones.setBorder(
                BorderFactory.createEmptyBorder(30, 50, 30, 50)
        );

        panelBotones.add(botonRegistrar);
        panelBotones.add(botonListar);
        panelBotones.add(botonEntrega);

        setLayout(new BorderLayout());

        add(titulo, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);

        botonRegistrar.addActionListener(e -> {
            new VentanaRegistroPedido();
        });

        botonListar.addActionListener(e -> {
            new VentanaListaPedidos();
        });

        botonEntrega.addActionListener(e -> {
            new VentanaEntrega();
        });
    }
}