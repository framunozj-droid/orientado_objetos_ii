package vista;

import model.ControladorPedidos;
import model.Pedido;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class VentanaListaPedidos extends JFrame {

    private JTable tablaPedidos;
    private DefaultTableModel modeloTabla;
    private JButton botonActualizar;

    public VentanaListaPedidos() {

        setTitle("Listado de Pedidos");
        setSize(650, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        crearComponentes();
        cargarPedidos();

        setVisible(true);
    }

    private void crearComponentes() {

        String[] columnas = {
                "ID",
                "Dirección",
                "Tipo",
                "Estado",
                "Repartidor"
        };

        modeloTabla = new DefaultTableModel(
                columnas,
                0
        );

        tablaPedidos = new JTable(modeloTabla);

        JScrollPane panelTabla =
                new JScrollPane(tablaPedidos);

        botonActualizar =
                new JButton("Actualizar");

        JPanel panelInferior = new JPanel();

        panelInferior.add(botonActualizar);

        setLayout(new BorderLayout());

        add(panelTabla, BorderLayout.CENTER);
        add(panelInferior, BorderLayout.SOUTH);

        botonActualizar.addActionListener(e -> {
            cargarPedidos();
        });
    }

    private void cargarPedidos() {

        modeloTabla.setRowCount(0);

        for (Pedido pedido :
                ControladorPedidos.obtenerPedidos()) {

            Object[] fila = {
                    pedido.getId(),
                    pedido.getDireccion(),
                    pedido.getTipo(),
                    pedido.getEstado(),
                    pedido.getRepartidor()
            };

            modeloTabla.addRow(fila);
        }
    }
}