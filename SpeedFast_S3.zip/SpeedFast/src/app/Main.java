package app;

import model.PedidoComida;
import model.PedidoEncomienda;
import model.PedidoExpress;
import servicio.ControladorDeEnvios;

public class Main {

    public static void main(String[] args) {

        PedidoComida comida = new PedidoComida(
                101,
                "Av. Italia 456",
                4
        );

        PedidoEncomienda encomienda = new PedidoEncomienda(
                102,
                "Av. Santa Rosa 567",
                7
        );

        PedidoExpress express = new PedidoExpress(
                103,
                "Av. Apoquindo 1500",
                8
        );

        ControladorDeEnvios controlador = new ControladorDeEnvios();

        System.out.println("PEDIDO COMIDA");
        comida.mostrarResumen();
        comida.asignarRepartidor();
        comida.asignarRepartidor("Luis Díaz");

        System.out.println(
                "Tiempo estimado: "
                        + comida.calcularTiempoEntrega()
                        + " minutos"
        );

        comida.despachar();

        controlador.agregarHistorial(
                "PedidoComida #101 - entregado por Luis Díaz"
        );

        System.out.println();
        System.out.println("PEDIDO ENCOMIENDA");

        encomienda.mostrarResumen();
        encomienda.asignarRepartidor();
        encomienda.asignarRepartidor("Daniela Tapia");

        System.out.println(
                "Tiempo estimado: "
                        + encomienda.calcularTiempoEntrega()
                        + " minutos"
        );

        encomienda.despachar();

        controlador.agregarHistorial(
                "PedidoEncomienda #102 - entregado por Daniela Tapia"
        );

        System.out.println();
        System.out.println("PEDIDO EXPRESS");

        express.mostrarResumen();
        express.asignarRepartidor();
        express.asignarRepartidor("Carlos Soto");

        System.out.println(
                "Tiempo estimado: "
                        + express.calcularTiempoEntrega()
                        + " minutos"
        );

        express.cancelar();

        controlador.verHistorial();
    }
}