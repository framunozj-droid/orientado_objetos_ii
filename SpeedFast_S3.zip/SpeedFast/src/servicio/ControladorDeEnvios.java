package servicio;

import java.util.ArrayList;

import interfaces.Rastreable;

public class ControladorDeEnvios implements Rastreable {

    private ArrayList<String> historial;

    public ControladorDeEnvios() {
        historial = new ArrayList<String>();
    }

    public void agregarHistorial(String texto) {
        historial.add(texto);
    }

    @Override
    public void verHistorial() {

        System.out.println();
        System.out.println("HISTORIAL DE ENTREGAS");
        System.out.println("---------------------");

        if (historial.size() == 0) {
            System.out.println("No existen entregas registradas.");
        } else {

            for (String registro : historial) {
                System.out.println("- " + registro);
            }
        }
    }
}