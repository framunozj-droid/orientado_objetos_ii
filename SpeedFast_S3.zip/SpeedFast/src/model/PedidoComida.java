package model;
import interfaces.Despachable;
import interfaces.Cancelable;

public class PedidoComida extends Pedido implements Despachable, Cancelable {

    public PedidoComida() {
        super();
    }

    public PedidoComida(int idPedido, String direccionEntrega, double distanciaKm) {
        super(idPedido, direccionEntrega, distanciaKm);
    }

    @Override
    public int calcularTiempoEntrega() {
        int tiempo = 15 + (int) (getDistanciaKm() * 2);
        return tiempo;
    }

    @Override
    public void mostrarResumen() {
        System.out.println("PedidoComida #" + getIdPedido());
        System.out.println("Dirección: " + getDireccionEntrega());
        System.out.println("Distancia: " + getDistanciaKm() + " km");
    }

    @Override
    public void despachar() {
        System.out.println("Pedido de comida despachado correctamente.");
    }

    @Override
    public void cancelar() {
        System.out.println("Pedido de comida cancelado.");
    }
    
}