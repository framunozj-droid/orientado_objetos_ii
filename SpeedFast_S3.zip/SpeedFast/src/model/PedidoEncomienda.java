package model;
import interfaces.Despachable;
import interfaces.Cancelable;

public class PedidoEncomienda extends Pedido implements Despachable, Cancelable{

    public PedidoEncomienda() {
        super();
    }

    public PedidoEncomienda(int idPedido, String direccionEntrega, double distanciaKm) {
        super(idPedido, direccionEntrega, distanciaKm);
    }

    @Override
    public int calcularTiempoEntrega() {

        double calculo = 20 + (getDistanciaKm() * 1.5);

        int tiempo = (int) calculo;

        return tiempo;
    }

    @Override
    public void mostrarResumen() {
        System.out.println("PedidoEncomienda #" + getIdPedido());
        System.out.println("Dirección: " + getDireccionEntrega());
        System.out.println("Distancia: " + getDistanciaKm() + " km");
    }
    
    @Override
    public void despachar() {
        System.out.println("Pedido de encomienda despachado correctamente.");
    }

    @Override
    public void cancelar() {
        System.out.println("Pedido de encomienda cancelado.");
    }


}