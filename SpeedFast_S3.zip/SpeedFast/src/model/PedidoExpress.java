package model;

import interfaces.Despachable;
import interfaces.Cancelable;

public class PedidoExpress extends Pedido implements Despachable, Cancelable {


    public PedidoExpress() {
        super();
    }

    public PedidoExpress(int idPedido, String direccionEntrega, double distanciaKm) {
        super(idPedido, direccionEntrega, distanciaKm);
    }

    @Override
    public int calcularTiempoEntrega() {

        int tiempo = 10;

        if (getDistanciaKm() > 5) {
            tiempo = tiempo + 5;
        }

        return tiempo;
    }

    @Override
    public void mostrarResumen() {
        System.out.println("PedidoExpress #" + getIdPedido());
        System.out.println("Dirección: " + getDireccionEntrega());
        System.out.println("Distancia: " + getDistanciaKm() + " km");
    }

    @Override
    public void despachar() {
        System.out.println("Pedido express despachado correctamente.");
    }

    @Override
    public void cancelar() {
        System.out.println("Pedido express cancelado.");
    }

}