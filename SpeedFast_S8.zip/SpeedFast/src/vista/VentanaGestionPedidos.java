package vista;

import dao.PedidoDAO;
import model.Pedido;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class VentanaGestionPedidos extends JFrame {

    private JTextField campoDireccion;
    private JComboBox<String> comboTipo;
    private JComboBox<String> comboEstado;

    private JTable tablaPedidos;
    private DefaultTableModel modeloTabla;

    private JButton botonGuardar;
    private JButton botonActualizar;
    private JButton botonEliminar;
    private JButton botonLimpiar;

    private int idSeleccionado = 0;

    private final PedidoDAO pedidoDAO;

    public VentanaGestionPedidos() {

        pedidoDAO = new PedidoDAO();

        setTitle("Gestión de Pedidos");
        setSize(800, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        crearComponentes();
        cargarPedidos();

        setVisible(true);
    }

    private void crearComponentes() {

        JLabel titulo = new JLabel(
                "GESTIÓN DE PEDIDOS",
                SwingConstants.CENTER
        );

        titulo.setFont(
                new Font("Arial", Font.BOLD, 18)
        );

        campoDireccion = new JTextField();

        comboTipo = new JComboBox<>(
                new String[]{
                        "COMIDA",
                        "ENCOMIENDA",
                        "EXPRESS"
                }
        );

        comboEstado = new JComboBox<>(
                new String[]{
                        "PENDIENTE",
                        "EN_REPARTO",
                        "ENTREGADO"
                }
        );

        botonGuardar = new JButton("Guardar");
        botonActualizar = new JButton("Actualizar");
        botonEliminar = new JButton("Eliminar");
        botonLimpiar = new JButton("Limpiar");

        JPanel formulario = new JPanel(
                new GridLayout(3, 2, 10, 10)
        );

        formulario.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        30,
                        10,
                        30
                )
        );

        formulario.add(new JLabel("Dirección:"));
        formulario.add(campoDireccion);

        formulario.add(new JLabel("Tipo:"));
        formulario.add(comboTipo);

        formulario.add(new JLabel("Estado:"));
        formulario.add(comboEstado);

        JPanel panelBotones = new JPanel();

        panelBotones.add(botonGuardar);
        panelBotones.add(botonActualizar);
        panelBotones.add(botonEliminar);
        panelBotones.add(botonLimpiar);

        String[] columnas = {
                "ID",
                "Dirección",
                "Tipo",
                "Estado"
        };

        modeloTabla = new DefaultTableModel(
                columnas,
                0
        ) {
            @Override
            public boolean isCellEditable(
                    int fila,
                    int columna) {

                return false;
            }
        };

        tablaPedidos = new JTable(modeloTabla);

        JScrollPane scroll =
                new JScrollPane(tablaPedidos);

        JPanel superior =
                new JPanel(new BorderLayout());

        superior.add(
                titulo,
                BorderLayout.NORTH
        );

        superior.add(
                formulario,
                BorderLayout.CENTER
        );

        superior.add(
                panelBotones,
                BorderLayout.SOUTH
        );

        setLayout(new BorderLayout());

        add(
                superior,
                BorderLayout.NORTH
        );

        add(
                scroll,
                BorderLayout.CENTER
        );

        botonGuardar.addActionListener(
                e -> guardar()
        );

        botonActualizar.addActionListener(
                e -> actualizar()
        );

        botonEliminar.addActionListener(
                e -> eliminar()
        );

        botonLimpiar.addActionListener(
                e -> limpiar()
        );

        tablaPedidos
                .getSelectionModel()
                .addListSelectionListener(
                        e -> seleccionarFila()
                );
    }

    /*
     * CREATE
     */
    private void guardar() {

        String direccion =
                campoDireccion
                        .getText()
                        .trim();

        if (direccion.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Debe ingresar una dirección."
            );

            return;
        }

        String tipo =
                comboTipo
                        .getSelectedItem()
                        .toString();

        String estado =
                comboEstado
                        .getSelectedItem()
                        .toString();

        Pedido pedido = new Pedido(
                direccion,
                tipo,
                estado
        );

        if (pedidoDAO.create(pedido)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Pedido registrado correctamente."
            );

            cargarPedidos();
            limpiar();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible registrar el pedido."
            );
        }
    }

    /*
     * READ
     */
    private void cargarPedidos() {

        modeloTabla.setRowCount(0);

        List<Pedido> pedidos =
                pedidoDAO.readAll();

        for (Pedido pedido : pedidos) {

            Object[] fila = {
                    pedido.getId(),
                    pedido.getDireccion(),
                    pedido.getTipo(),
                    pedido.getEstado()
            };

            modeloTabla.addRow(fila);
        }
    }

    /*
     * UPDATE
     */
    private void actualizar() {

        if (idSeleccionado == 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione un pedido de la tabla."
            );

            return;
        }

        String direccion =
                campoDireccion
                        .getText()
                        .trim();

        if (direccion.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "La dirección es obligatoria."
            );

            return;
        }

        String tipo =
                comboTipo
                        .getSelectedItem()
                        .toString();

        String estado =
                comboEstado
                        .getSelectedItem()
                        .toString();

        Pedido pedido = new Pedido(
                idSeleccionado,
                direccion,
                tipo,
                estado
        );

        if (pedidoDAO.update(pedido)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Pedido actualizado correctamente."
            );

            cargarPedidos();
            limpiar();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible actualizar el pedido."
            );
        }
    }

    /*
     * DELETE
     */
    private void eliminar() {

        if (idSeleccionado == 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione un pedido de la tabla."
            );

            return;
        }

        int respuesta =
                JOptionPane.showConfirmDialog(
                        this,
                        "¿Desea eliminar el pedido seleccionado?",
                        "Confirmar eliminación",
                        JOptionPane.YES_NO_OPTION
                );

        if (respuesta !=
                JOptionPane.YES_OPTION) {

            return;
        }

        if (pedidoDAO.delete(idSeleccionado)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Pedido eliminado correctamente."
            );

            cargarPedidos();
            limpiar();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible eliminar el pedido.\n"
                    + "Puede tener una entrega asociada."
            );
        }
    }

    private void seleccionarFila() {

        int fila =
                tablaPedidos.getSelectedRow();

        if (fila == -1) {
            return;
        }

        idSeleccionado =
                Integer.parseInt(
                        modeloTabla
                                .getValueAt(fila, 0)
                                .toString()
                );

        campoDireccion.setText(
                modeloTabla
                        .getValueAt(fila, 1)
                        .toString()
        );

        comboTipo.setSelectedItem(
                modeloTabla
                        .getValueAt(fila, 2)
                        .toString()
        );

        comboEstado.setSelectedItem(
                modeloTabla
                        .getValueAt(fila, 3)
                        .toString()
        );
    }

    private void limpiar() {

        idSeleccionado = 0;

        campoDireccion.setText("");

        comboTipo.setSelectedIndex(0);
        comboEstado.setSelectedIndex(0);

        tablaPedidos.clearSelection();

        campoDireccion.requestFocus();
    }
}