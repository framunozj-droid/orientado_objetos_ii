package vista;

import dao.EntregaDAO;
import dao.PedidoDAO;
import dao.RepartidorDAO;

import model.Entrega;
import model.Pedido;
import model.Repartidor;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

import java.sql.Date;
import java.sql.Time;

import java.time.LocalDate;
import java.time.LocalTime;

import java.util.List;

public class VentanaGestionEntregas extends JFrame {

    private JComboBox<Pedido> comboPedido;
    private JComboBox<Repartidor> comboRepartidor;

    private JTextField campoFecha;
    private JTextField campoHora;

    private JTable tablaEntregas;
    private DefaultTableModel modeloTabla;

    private JButton botonGuardar;
    private JButton botonActualizar;
    private JButton botonEliminar;
    private JButton botonLimpiar;

    private int idSeleccionado = 0;

    private final EntregaDAO entregaDAO;
    private final PedidoDAO pedidoDAO;
    private final RepartidorDAO repartidorDAO;

    public VentanaGestionEntregas() {

        entregaDAO = new EntregaDAO();
        pedidoDAO = new PedidoDAO();
        repartidorDAO = new RepartidorDAO();

        setTitle("Gestión de Entregas");
        setSize(850, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        crearComponentes();

        cargarCombos();
        cargarEntregas();

        setVisible(true);
    }

    private void crearComponentes() {

        JLabel titulo = new JLabel(
                "GESTIÓN DE ENTREGAS",
                SwingConstants.CENTER
        );

        titulo.setFont(
                new Font("Arial", Font.BOLD, 18)
        );

        comboPedido = new JComboBox<>();
        comboRepartidor = new JComboBox<>();

        campoFecha = new JTextField(
                LocalDate.now().toString()
        );

        campoHora = new JTextField(
                LocalTime.now()
                        .withNano(0)
                        .toString()
        );

        botonGuardar = new JButton("Guardar");
        botonActualizar = new JButton("Actualizar");
        botonEliminar = new JButton("Eliminar");
        botonLimpiar = new JButton("Limpiar");

        JPanel panelFormulario = new JPanel(
                new GridLayout(4, 2, 10, 10)
        );

        panelFormulario.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        30,
                        10,
                        30
                )
        );

        panelFormulario.add(
                new JLabel("Pedido:")
        );

        panelFormulario.add(comboPedido);

        panelFormulario.add(
                new JLabel("Repartidor:")
        );

        panelFormulario.add(comboRepartidor);

        panelFormulario.add(
                new JLabel("Fecha (AAAA-MM-DD):")
        );

        panelFormulario.add(campoFecha);

        panelFormulario.add(
                new JLabel("Hora (HH:MM:SS):")
        );

        panelFormulario.add(campoHora);

        JPanel panelBotones = new JPanel();

        panelBotones.add(botonGuardar);
        panelBotones.add(botonActualizar);
        panelBotones.add(botonEliminar);
        panelBotones.add(botonLimpiar);

        String[] columnas = {
                "ID",
                "Pedido",
                "Repartidor",
                "Fecha",
                "Hora"
        };

        modeloTabla = new DefaultTableModel(
                columnas,
                0
        ) {
            @Override
            public boolean isCellEditable(
                    int fila,
                    int columna) {

                return false;
            }
        };

        tablaEntregas = new JTable(modeloTabla);

        JScrollPane scroll =
                new JScrollPane(tablaEntregas);

        JPanel panelSuperior =
                new JPanel(new BorderLayout());

        panelSuperior.add(
                titulo,
                BorderLayout.NORTH
        );

        panelSuperior.add(
                panelFormulario,
                BorderLayout.CENTER
        );

        panelSuperior.add(
                panelBotones,
                BorderLayout.SOUTH
        );

        setLayout(new BorderLayout());

        add(
                panelSuperior,
                BorderLayout.NORTH
        );

        add(
                scroll,
                BorderLayout.CENTER
        );

        botonGuardar.addActionListener(
                e -> guardar()
        );

        botonActualizar.addActionListener(
                e -> actualizar()
        );

        botonEliminar.addActionListener(
                e -> eliminar()
        );

        botonLimpiar.addActionListener(
                e -> limpiar()
        );

        tablaEntregas
                .getSelectionModel()
                .addListSelectionListener(
                        e -> {

                            if (!e.getValueIsAdjusting()) {
                                seleccionarFila();
                            }
                        }
                );
    }

    /*
     * Carga los pedidos y repartidores
     * registrados en la base de datos.
     */
    private void cargarCombos() {

        comboPedido.removeAllItems();
        comboRepartidor.removeAllItems();

        List<Pedido> pedidos =
                pedidoDAO.readAll();

        for (Pedido pedido : pedidos) {
            comboPedido.addItem(pedido);
        }

        List<Repartidor> repartidores =
                repartidorDAO.readAll();

        for (Repartidor repartidor : repartidores) {
            comboRepartidor.addItem(repartidor);
        }
    }

    /*
     * CREATE
     */
    private void guardar() {

        Pedido pedido =
                (Pedido) comboPedido.getSelectedItem();

        Repartidor repartidor =
                (Repartidor) comboRepartidor.getSelectedItem();

        if (pedido == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Debe seleccionar un pedido."
            );

            return;
        }

        if (repartidor == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Debe seleccionar un repartidor."
            );

            return;
        }

        try {

            Date fecha = Date.valueOf(
                    campoFecha.getText().trim()
            );

            Time hora = Time.valueOf(
                    campoHora.getText().trim()
            );

            Entrega entrega = new Entrega(
                    pedido.getId(),
                    repartidor.getId(),
                    fecha,
                    hora
            );

            boolean resultado =
                    entregaDAO.create(entrega);

            if (resultado) {

                JOptionPane.showMessageDialog(
                        this,
                        "Entrega registrada correctamente."
                );

                cargarEntregas();
                limpiar();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No fue posible registrar la entrega."
                );
            }

        } catch (IllegalArgumentException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Fecha u hora inválida.\n"
                    + "Fecha: AAAA-MM-DD\n"
                    + "Hora: HH:MM:SS"
            );
        }
    }

    /*
     * READ
     */
    private void cargarEntregas() {

        modeloTabla.setRowCount(0);

        List<Entrega> entregas =
                entregaDAO.readAll();

        for (Entrega entrega : entregas) {

            String textoPedido =
                    obtenerTextoPedido(
                            entrega.getIdPedido()
                    );

            String textoRepartidor =
                    obtenerTextoRepartidor(
                            entrega.getIdRepartidor()
                    );

            Object[] fila = {
                    entrega.getId(),
                    textoPedido,
                    textoRepartidor,
                    entrega.getFecha(),
                    entrega.getHora()
            };

            modeloTabla.addRow(fila);
        }
    }

    /*
     * UPDATE
     */
    private void actualizar() {

        if (idSeleccionado == 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione una entrega de la tabla."
            );

            return;
        }

        Pedido pedido =
                (Pedido) comboPedido.getSelectedItem();

        Repartidor repartidor =
                (Repartidor) comboRepartidor.getSelectedItem();

        if (pedido == null ||
                repartidor == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Debe seleccionar pedido y repartidor."
            );

            return;
        }

        try {

            Date fecha = Date.valueOf(
                    campoFecha.getText().trim()
            );

            Time hora = Time.valueOf(
                    campoHora.getText().trim()
            );

            Entrega entrega = new Entrega(
                    idSeleccionado,
                    pedido.getId(),
                    repartidor.getId(),
                    fecha,
                    hora
            );

            boolean resultado =
                    entregaDAO.update(entrega);

            if (resultado) {

                JOptionPane.showMessageDialog(
                        this,
                        "Entrega actualizada correctamente."
                );

                cargarEntregas();
                limpiar();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No fue posible actualizar la entrega."
                );
            }

        } catch (IllegalArgumentException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Fecha u hora inválida.\n"
                    + "Fecha: AAAA-MM-DD\n"
                    + "Hora: HH:MM:SS"
            );
        }
    }

    /*
     * DELETE
     */
    private void eliminar() {

        if (idSeleccionado == 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione una entrega de la tabla."
            );

            return;
        }

        int respuesta =
                JOptionPane.showConfirmDialog(
                        this,
                        "¿Desea eliminar la entrega seleccionada?",
                        "Confirmar eliminación",
                        JOptionPane.YES_NO_OPTION
                );

        if (respuesta !=
                JOptionPane.YES_OPTION) {

            return;
        }

        boolean resultado =
                entregaDAO.delete(idSeleccionado);

        if (resultado) {

            JOptionPane.showMessageDialog(
                    this,
                    "Entrega eliminada correctamente."
            );

            cargarEntregas();
            limpiar();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible eliminar la entrega."
            );
        }
    }

    /*
     * Carga en el formulario los datos
     * de la entrega seleccionada.
     */
    private void seleccionarFila() {

        int fila =
                tablaEntregas.getSelectedRow();

        if (fila == -1) {
            return;
        }

        idSeleccionado =
                Integer.parseInt(
                        modeloTabla
                                .getValueAt(fila, 0)
                                .toString()
                );

        campoFecha.setText(
                modeloTabla
                        .getValueAt(fila, 3)
                        .toString()
        );

        campoHora.setText(
                modeloTabla
                        .getValueAt(fila, 4)
                        .toString()
        );

        Entrega entregaSeleccionada =
                buscarEntrega(idSeleccionado);

        if (entregaSeleccionada == null) {
            return;
        }

        seleccionarPedido(
                entregaSeleccionada.getIdPedido()
        );

        seleccionarRepartidor(
                entregaSeleccionada.getIdRepartidor()
        );
    }

    /*
     * Busca una entrega por ID dentro
     * de los datos recuperados desde la BD.
     */
    private Entrega buscarEntrega(int id) {

        List<Entrega> entregas =
                entregaDAO.readAll();

        for (Entrega entrega : entregas) {

            if (entrega.getId() == id) {
                return entrega;
            }
        }

        return null;
    }

    /*
     * Selecciona el pedido correspondiente
     * dentro del JComboBox.
     */
    private void seleccionarPedido(int idPedido) {

        for (int i = 0;
             i < comboPedido.getItemCount();
             i++) {

            Pedido pedido =
                    comboPedido.getItemAt(i);

            if (pedido.getId() == idPedido) {

                comboPedido.setSelectedIndex(i);

                return;
            }
        }
    }

    /*
     * Selecciona el repartidor correspondiente
     * dentro del JComboBox.
     */
    private void seleccionarRepartidor(
            int idRepartidor) {

        for (int i = 0;
             i < comboRepartidor.getItemCount();
             i++) {

            Repartidor repartidor =
                    comboRepartidor.getItemAt(i);

            if (repartidor.getId()
                    == idRepartidor) {

                comboRepartidor
                        .setSelectedIndex(i);

                return;
            }
        }
    }

    /*
     * Obtiene texto legible del pedido.
     */
    private String obtenerTextoPedido(
            int idPedido) {

        List<Pedido> pedidos =
                pedidoDAO.readAll();

        for (Pedido pedido : pedidos) {

            if (pedido.getId() == idPedido) {

                return pedido.getId()
                        + " - "
                        + pedido.getDireccion();
            }
        }

        return String.valueOf(idPedido);
    }

    /*
     * Obtiene texto legible del repartidor.
     */
    private String obtenerTextoRepartidor(
            int idRepartidor) {

        List<Repartidor> repartidores =
                repartidorDAO.readAll();

        for (Repartidor repartidor :
                repartidores) {

            if (repartidor.getId()
                    == idRepartidor) {

                return repartidor.getId()
                        + " - "
                        + repartidor.getNombre();
            }
        }

        return String.valueOf(idRepartidor);
    }

    /*
     * Limpia el formulario.
     */
    private void limpiar() {

        idSeleccionado = 0;

        tablaEntregas.clearSelection();

        if (comboPedido.getItemCount() > 0) {
            comboPedido.setSelectedIndex(0);
        }

        if (comboRepartidor.getItemCount() > 0) {
            comboRepartidor.setSelectedIndex(0);
        }

        campoFecha.setText(
                LocalDate.now().toString()
        );

        campoHora.setText(
                LocalTime.now()
                        .withNano(0)
                        .toString()
        );
    }
}