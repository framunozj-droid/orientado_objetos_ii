package vista;

import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {

    private JButton botonRepartidores;
    private JButton botonPedidos;
    private JButton botonEntregas;

    public VentanaPrincipal() {

        setTitle("SpeedFast - Gestión de Entregas");
        setSize(500, 330);

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setLocationRelativeTo(null);

        crearComponentes();

        setVisible(true);
    }

    private void crearComponentes() {

        JLabel titulo = new JLabel(
                "SPEEDFAST",
                SwingConstants.CENTER
        );

        titulo.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        24
                )
        );

        JLabel subtitulo = new JLabel(
                "Sistema de Gestión de Entregas",
                SwingConstants.CENTER
        );

        botonRepartidores =
                new JButton("Gestionar Repartidores");

        botonPedidos =
                new JButton("Gestionar Pedidos");

        botonEntregas =
                new JButton("Gestionar Entregas");


        /*
         * Encabezado de la ventana
         */

        JPanel encabezado =
                new JPanel(
                        new GridLayout(
                                2,
                                1
                        )
                );

        encabezado.add(titulo);
        encabezado.add(subtitulo);


        /*
         * Panel principal de botones
         */

        JPanel panelBotones =
                new JPanel(
                        new GridLayout(
                                3,
                                1,
                                10,
                                10
                        )
                );

        panelBotones.setBorder(
                BorderFactory.createEmptyBorder(
                        35,
                        60,
                        35,
                        60
                )
        );

        panelBotones.add(
                botonRepartidores
        );

        panelBotones.add(
                botonPedidos
        );

        panelBotones.add(
                botonEntregas
        );


        /*
         * Organización de la ventana
         */

        setLayout(
                new BorderLayout()
        );

        add(
                encabezado,
                BorderLayout.NORTH
        );

        add(
                panelBotones,
                BorderLayout.CENTER
        );


        /*
         * Navegación
         */

        botonRepartidores.addActionListener(
                e -> new VentanaGestionRepartidores()
        );

        botonPedidos.addActionListener(
                e -> new VentanaGestionPedidos()
        );

        botonEntregas.addActionListener(
                e -> new VentanaGestionEntregas()
        );
    }
}