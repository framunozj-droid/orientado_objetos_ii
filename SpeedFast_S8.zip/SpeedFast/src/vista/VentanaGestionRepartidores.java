package vista;

import dao.RepartidorDAO;
import model.Repartidor;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class VentanaGestionRepartidores extends JFrame {

    private JTextField campoNombre;

    private JButton botonGuardar;
    private JButton botonActualizar;
    private JButton botonEliminar;
    private JButton botonLimpiar;

    private JTable tablaRepartidores;
    private DefaultTableModel modeloTabla;

    private int idSeleccionado = 0;

    private RepartidorDAO repartidorDAO;

    public VentanaGestionRepartidores() {

        repartidorDAO = new RepartidorDAO();

        setTitle("Gestión de Repartidores");
        setSize(650, 500);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        crearComponentes();
        cargarRepartidores();

        setVisible(true);
    }

    private void crearComponentes() {

        JLabel titulo = new JLabel(
                "GESTIÓN DE REPARTIDORES",
                SwingConstants.CENTER
        );

        titulo.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        campoNombre = new JTextField();

        botonGuardar =
                new JButton("Guardar");

        botonActualizar =
                new JButton("Actualizar");

        botonEliminar =
                new JButton("Eliminar");

        botonLimpiar =
                new JButton("Limpiar");


        /*
         * Panel del formulario
         */

        JPanel panelFormulario =
                new JPanel(
                        new GridLayout(
                                2,
                                2,
                                10,
                                10
                        )
                );

        panelFormulario.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        30,
                        10,
                        30
                )
        );

        panelFormulario.add(
                new JLabel("Nombre:")
        );

        panelFormulario.add(campoNombre);


        /*
         * Panel de botones
         */

        JPanel panelBotones =
                new JPanel();

        panelBotones.add(botonGuardar);
        panelBotones.add(botonActualizar);
        panelBotones.add(botonEliminar);
        panelBotones.add(botonLimpiar);


        /*
         * Tabla
         */

        String[] columnas = {
                "ID",
                "Nombre"
        };

        modeloTabla =
                new DefaultTableModel(
                        columnas,
                        0
                ) {

                    @Override
                    public boolean isCellEditable(
                            int fila,
                            int columna) {

                        return false;
                    }
                };

        tablaRepartidores =
                new JTable(modeloTabla);

        JScrollPane scrollTabla =
                new JScrollPane(
                        tablaRepartidores
                );


        /*
         * Panel superior
         */

        JPanel panelSuperior =
                new JPanel(
                        new BorderLayout()
                );

        panelSuperior.add(
                titulo,
                BorderLayout.NORTH
        );

        panelSuperior.add(
                panelFormulario,
                BorderLayout.CENTER
        );

        panelSuperior.add(
                panelBotones,
                BorderLayout.SOUTH
        );


        /*
         * Ventana
         */

        setLayout(
                new BorderLayout()
        );

        add(
                panelSuperior,
                BorderLayout.NORTH
        );

        add(
                scrollTabla,
                BorderLayout.CENTER
        );


        /*
         * Eventos
         */

        botonGuardar.addActionListener(
                e -> guardar()
        );

        botonActualizar.addActionListener(
                e -> actualizar()
        );

        botonEliminar.addActionListener(
                e -> eliminar()
        );

        botonLimpiar.addActionListener(
                e -> limpiar()
        );

        tablaRepartidores
                .getSelectionModel()
                .addListSelectionListener(
                        e -> seleccionarFila()
                );
    }


    /*
     * CREATE
     */

    private void guardar() {

        String nombre =
                campoNombre
                        .getText()
                        .trim();

        if (nombre.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Debe ingresar el nombre del repartidor."
            );

            return;
        }

        Repartidor repartidor =
                new Repartidor();

        repartidor.setNombre(nombre);

        boolean resultado =
                repartidorDAO.create(
                        repartidor
                );

        if (resultado) {

            JOptionPane.showMessageDialog(
                    this,
                    "Repartidor registrado correctamente."
            );

            cargarRepartidores();
            limpiar();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible registrar el repartidor."
            );
        }
    }


    /*
     * READ
     */

    private void cargarRepartidores() {

        modeloTabla.setRowCount(0);

        List<Repartidor> repartidores =
                repartidorDAO.readAll();

        for (Repartidor repartidor :
                repartidores) {

            Object[] fila = {
                    repartidor.getId(),
                    repartidor.getNombre()
            };

            modeloTabla.addRow(fila);
        }
    }


    /*
     * UPDATE
     */

    private void actualizar() {

        if (idSeleccionado == 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione un repartidor de la tabla."
            );

            return;
        }

        String nombre =
                campoNombre
                        .getText()
                        .trim();

        if (nombre.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "El nombre no puede estar vacío."
            );

            return;
        }

        Repartidor repartidor =
                new Repartidor(
                        idSeleccionado,
                        nombre
                );

        boolean resultado =
                repartidorDAO.update(
                        repartidor
                );

        if (resultado) {

            JOptionPane.showMessageDialog(
                    this,
                    "Repartidor actualizado correctamente."
            );

            cargarRepartidores();
            limpiar();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible actualizar el repartidor."
            );
        }
    }


    /*
     * DELETE
     */

    private void eliminar() {

        if (idSeleccionado == 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione un repartidor de la tabla."
            );

            return;
        }

        int respuesta =
                JOptionPane.showConfirmDialog(
                        this,
                        "¿Desea eliminar el repartidor seleccionado?",
                        "Confirmar eliminación",
                        JOptionPane.YES_NO_OPTION
                );

        if (respuesta !=
                JOptionPane.YES_OPTION) {

            return;
        }

        boolean resultado =
                repartidorDAO.delete(
                        idSeleccionado
                );

        if (resultado) {

            JOptionPane.showMessageDialog(
                    this,
                    "Repartidor eliminado correctamente."
            );

            cargarRepartidores();
            limpiar();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible eliminar el repartidor."
            );
        }
    }


    /*
     * Carga los datos de la fila seleccionada
     * en el formulario.
     */

    private void seleccionarFila() {

        int fila =
                tablaRepartidores
                        .getSelectedRow();

        if (fila == -1) {
            return;
        }

        idSeleccionado =
                Integer.parseInt(
                        modeloTabla
                                .getValueAt(
                                        fila,
                                        0
                                )
                                .toString()
                );

        campoNombre.setText(
                modeloTabla
                        .getValueAt(
                                fila,
                                1
                        )
                        .toString()
        );
    }


    /*
     * Limpia el formulario.
     */

    private void limpiar() {

        idSeleccionado = 0;

        campoNombre.setText("");

        tablaRepartidores
                .clearSelection();

        campoNombre
                .requestFocus();
    }
}