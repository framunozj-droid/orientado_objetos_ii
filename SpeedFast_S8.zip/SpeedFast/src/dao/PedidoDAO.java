package dao;

import model.Pedido;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    /*
     * CREATE
     * Registra un nuevo pedido en la base de datos.
     */
    public boolean create(Pedido pedido) {

        String sql =
                "INSERT INTO pedidos "
                + "(direccion, tipo, estado) "
                + "VALUES (?, ?, ?)";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement sentencia =
                    conexion.prepareStatement(sql)
        ) {

            sentencia.setString(
                    1,
                    pedido.getDireccion()
            );

            sentencia.setString(
                    2,
                    pedido.getTipo()
            );

            sentencia.setString(
                    3,
                    pedido.getEstado()
            );

            sentencia.executeUpdate();

            return true;

        } catch (SQLException e) {

            System.out.println(
                    "Error al registrar pedido: "
                    + e.getMessage()
            );

            return false;
        }
    }


    /*
     * READ
     * Obtiene todos los pedidos registrados.
     */
    public List<Pedido> readAll() {

        List<Pedido> pedidos =
                new ArrayList<>();

        String sql =
                "SELECT id, direccion, tipo, estado "
                + "FROM pedidos "
                + "ORDER BY id";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement sentencia =
                    conexion.prepareStatement(sql);
            ResultSet resultado =
                    sentencia.executeQuery()
        ) {

            while (resultado.next()) {

                Pedido pedido =
                        new Pedido(
                                resultado.getInt("id"),
                                resultado.getString("direccion"),
                                resultado.getString("tipo"),
                                resultado.getString("estado")
                        );

                pedidos.add(pedido);
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error al listar pedidos: "
                    + e.getMessage()
            );
        }

        return pedidos;
    }


    /*
     * UPDATE
     * Actualiza direccion, tipo y estado de un pedido.
     */
    public boolean update(Pedido pedido) {

        String sql =
                "UPDATE pedidos "
                + "SET direccion = ?, "
                + "tipo = ?, "
                + "estado = ? "
                + "WHERE id = ?";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement sentencia =
                    conexion.prepareStatement(sql)
        ) {

            sentencia.setString(
                    1,
                    pedido.getDireccion()
            );

            sentencia.setString(
                    2,
                    pedido.getTipo()
            );

            sentencia.setString(
                    3,
                    pedido.getEstado()
            );

            sentencia.setInt(
                    4,
                    pedido.getId()
            );

            int filas =
                    sentencia.executeUpdate();

            return filas > 0;

        } catch (SQLException e) {

            System.out.println(
                    "Error al actualizar pedido: "
                    + e.getMessage()
            );

            return false;
        }
    }


    /*
     * DELETE
     * Elimina un pedido utilizando su ID.
     */
    public boolean delete(int id) {

        String sql =
                "DELETE FROM pedidos "
                + "WHERE id = ?";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement sentencia =
                    conexion.prepareStatement(sql)
        ) {

            sentencia.setInt(1, id);

            int filas =
                    sentencia.executeUpdate();

            return filas > 0;

        } catch (SQLException e) {

            System.out.println(
                    "Error al eliminar pedido: "
                    + e.getMessage()
            );

            return false;
        }
    }
}