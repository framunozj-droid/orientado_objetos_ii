package dao;

import model.Entrega;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

public class EntregaDAO {

    /*
     * CREATE
     * Registra una nueva entrega.
     */
    public boolean create(Entrega entrega) {

        String sql =
                "INSERT INTO entregas "
                + "(id_pedido, id_repartidor, fecha, hora) "
                + "VALUES (?, ?, ?, ?)";

        try (
                Connection conexion = ConexionBD.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql)
        ) {

            sentencia.setInt(
                    1,
                    entrega.getIdPedido()
            );

            sentencia.setInt(
                    2,
                    entrega.getIdRepartidor()
            );

            sentencia.setDate(
                    3,
                    entrega.getFecha()
            );

            sentencia.setTime(
                    4,
                    entrega.getHora()
            );

            sentencia.executeUpdate();

            return true;

        } catch (SQLException e) {

            System.out.println(
                    "Error al registrar entrega: "
                    + e.getMessage()
            );

            return false;
        }
    }

    /*
     * READ
     * Lista todas las entregas.
     */
    public List<Entrega> readAll() {

        List<Entrega> entregas =
                new ArrayList<>();

        String sql =
                "SELECT id, id_pedido, id_repartidor, fecha, hora "
                + "FROM entregas "
                + "ORDER BY id";

        try (
                Connection conexion = ConexionBD.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql);
                ResultSet resultado =
                        sentencia.executeQuery()
        ) {

            while (resultado.next()) {

                Entrega entrega =
                        new Entrega(
                                resultado.getInt("id"),
                                resultado.getInt("id_pedido"),
                                resultado.getInt("id_repartidor"),
                                resultado.getDate("fecha"),
                                resultado.getTime("hora")
                        );

                entregas.add(entrega);
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error al listar entregas: "
                    + e.getMessage()
            );
        }

        return entregas;
    }

    /*
     * UPDATE
     * Actualiza una entrega existente.
     */
    public boolean update(Entrega entrega) {

        String sql =
                "UPDATE entregas "
                + "SET id_pedido = ?, "
                + "id_repartidor = ?, "
                + "fecha = ?, "
                + "hora = ? "
                + "WHERE id = ?";

        try (
                Connection conexion = ConexionBD.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql)
        ) {

            sentencia.setInt(
                    1,
                    entrega.getIdPedido()
            );

            sentencia.setInt(
                    2,
                    entrega.getIdRepartidor()
            );

            sentencia.setDate(
                    3,
                    entrega.getFecha()
            );

            sentencia.setTime(
                    4,
                    entrega.getHora()
            );

            sentencia.setInt(
                    5,
                    entrega.getId()
            );

            int filas =
                    sentencia.executeUpdate();

            return filas > 0;

        } catch (SQLException e) {

            System.out.println(
                    "Error al actualizar entrega: "
                    + e.getMessage()
            );

            return false;
        }
    }

    /*
     * DELETE
     * Elimina una entrega por ID.
     */
    public boolean delete(int id) {

        String sql =
                "DELETE FROM entregas "
                + "WHERE id = ?";

        try (
                Connection conexion = ConexionBD.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql)
        ) {

            sentencia.setInt(1, id);

            int filas =
                    sentencia.executeUpdate();

            return filas > 0;

        } catch (SQLException e) {

            System.out.println(
                    "Error al eliminar entrega: "
                    + e.getMessage()
            );

            return false;
        }
    }
}