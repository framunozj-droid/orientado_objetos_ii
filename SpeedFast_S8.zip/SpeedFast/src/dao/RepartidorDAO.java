package dao;

import model.Repartidor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

public class RepartidorDAO {

    /*
     * CREATE
     * Registra un nuevo repartidor.
     */
    public boolean create(Repartidor repartidor) {

        String sql =
                "INSERT INTO repartidores (nombre) VALUES (?)";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement sentencia =
                    conexion.prepareStatement(sql)
        ) {

            sentencia.setString(
                    1,
                    repartidor.getNombre()
            );

            sentencia.executeUpdate();

            return true;

        } catch (SQLException e) {

            System.out.println(
                    "Error al registrar repartidor: "
                    + e.getMessage()
            );

            return false;
        }
    }


    /*
     * READ
     * Obtiene todos los repartidores.
     */
    public List<Repartidor> readAll() {

        List<Repartidor> repartidores =
                new ArrayList<>();

        String sql =
                "SELECT id, nombre "
                + "FROM repartidores "
                + "ORDER BY id";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement sentencia =
                    conexion.prepareStatement(sql);
            ResultSet resultado =
                    sentencia.executeQuery()
        ) {

            while (resultado.next()) {

                Repartidor repartidor =
                        new Repartidor(
                                resultado.getInt("id"),
                                resultado.getString("nombre")
                        );

                repartidores.add(repartidor);
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error al listar repartidores: "
                    + e.getMessage()
            );
        }

        return repartidores;
    }


    /*
     * UPDATE
     * Modifica el nombre de un repartidor.
     */
    public boolean update(Repartidor repartidor) {

        String sql =
                "UPDATE repartidores "
                + "SET nombre = ? "
                + "WHERE id = ?";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement sentencia =
                    conexion.prepareStatement(sql)
        ) {

            sentencia.setString(
                    1,
                    repartidor.getNombre()
            );

            sentencia.setInt(
                    2,
                    repartidor.getId()
            );

            int filas =
                    sentencia.executeUpdate();

            return filas > 0;

        } catch (SQLException e) {

            System.out.println(
                    "Error al actualizar repartidor: "
                    + e.getMessage()
            );

            return false;
        }
    }


    /*
     * DELETE
     * Elimina un repartidor por su ID.
     */
    public boolean delete(int id) {

        String sql =
                "DELETE FROM repartidores "
                + "WHERE id = ?";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement sentencia =
                    conexion.prepareStatement(sql)
        ) {

            sentencia.setInt(1, id);

            int filas =
                    sentencia.executeUpdate();

            return filas > 0;

        } catch (SQLException e) {

            System.out.println(
                    "Error al eliminar repartidor: "
                    + e.getMessage()
            );

            return false;
        }
    }
}